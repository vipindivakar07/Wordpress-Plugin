<?php
/** 
 * Plugin Name: Lead Generation Builder Forms
 * Description: just an example for the lead generation
 * Plugin URI: https://www.dightinfotech.com/
* Version: 1.1
* Author: Dight Infotech
* Author URI: https://www.dightinfotech.com/
*/

global $dight_fbuilder_lead_generation_version,$dight_fbuilder_lead_generation_db_version;
$dight_fbuilder_lead_generation_version = '1.0';
$dight_fbuilder_lead_generation_db_version = '1.0';
define( 'dight_fbuilder_lead_generation_plugin_path', plugins_url(__FILE__ ) ); 
define( 'dight_fbuilder_lead_generation_plugin_dir_path', plugin_dir_path(__FILE__ ) ); 
require_once('classes/builderdatabase.php' );
require_once('classes/function.php' );

function admin_menu(){
    add_menu_page('Forms','Form Builder','manage_options','dight-fbuilder-create-form','dight_fbuilder_lead_admin_menu','dashicons-cart',4);
    add_submenu_page('dight-fbuilder-create-form','Manage Cat & Questions','Manage Cat & Questions','manage_options','fbuilder-manage-cat-and-questions','dight_fbuilder_managecat_questions');
    add_submenu_page('dight-fbuilder-create-form','Manage Primary Form','Manage Primary Form','manage_options','fbuilder-manage-primary-form','dight_fbuilder_manage_primary_form');
    add_submenu_page('dight-fbuilder-create-form','Combine Form','Combine Form','manage_options','fbuilder-combine-form','dight_fbuilder_combine_form');
    add_submenu_page('dight-fbuilder-create-form','See All Data','See All Data','manage_options','see-all-data','dight_fbuilder_see_all_data');
    add_submenu_page('dight-fbuilder-create-form','Setting','Setting','manage_options','setting','dight_fbuilder_setting');
    add_submenu_page('dight-fbuilder-create-form','Splash Screen','Splash Screen','manage_options','Splash-Screen','dight_fbuilder_splash_screen');
    // edit primary form 
    add_submenu_page('','Edit Primary Form','Edit Primary Form','manage_options','edit-fbuilder-primary-form','edit_fbuilder_primary_form');
    // edit category form
    add_submenu_page('','Edit Category Form','Edit Category Form','manage_options','edit-fbuilder-category-form','edit_fbuilder_category_form');
    // edit form fields
    add_submenu_page('','Edit Form Field','Edit Form Field','manage_options','edit-fbuilder-form-field','edit_fbuilder_form_field');
    // edit combine form
    add_submenu_page('','Edit Combine Form','Edit Combine Form','manage_options','edit-fbuilder-combine-form','edit_fbuilder_combine_form');
    new dight_fbuilder_formCommon();
    new dight_fbuilder_form_field();
}
add_action('admin_menu','admin_menu');

function dight_fbuilder_manage_primary_form(){
    require_once('classes/manage_primary_categoryform.php' );
    $builderprimaryandcatform = new dight_fbuilder_primaryandcatform();
    echo $builderprimaryandcatform->dight_fbuilder_primaryformhtml(); 
}

function dight_fbuilder_managecat_questions(){
    require_once('classes/manage_primary_categoryform.php' );
    $builderprimaryandcatform = new dight_fbuilder_primaryandcatform();
    echo $builderprimaryandcatform->dight_fbuilder_categoryformhtml(); 
}

function dight_fbuilder_combine_form(){
    require_once('classes/combineforms.php' );
    $dight_fbuilder_combineforms = new dight_fbuilder_combineforms();
    echo $dight_fbuilder_combineforms->dight_fbuilder_combinehtml(); 
}

function dight_fbuilder_see_all_data(){
    require_once('classes/manage_primary_categoryform.php' );
    $builderseealldatform = new dight_fbuilder_primaryandcatform();
    echo $builderseealldatform->dight_fbuilder_seealldata_formhtml();
}

function dight_fbuilder_splash_screen(){
    require_once('classes/manage_primary_categoryform.php' );
    $buildersplash_screenform = new dight_fbuilder_primaryandcatform();
    echo $buildersplash_screenform->dight_fbuilder_buildersplash_screen_form();
}

function dight_fbuilder_setting(){
    require_once('classes/manage_primary_categoryform.php' );
    $builder_setting_form = new dight_fbuilder_primaryandcatform();
    echo $builder_setting_form->dight_fbuilder_setting_form();
}

function dight_fbuilder_lead_admin_menu(){
    //insert form data start
    global $wpdb;
    $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';
    if ( isset( $_POST['submit'] ) ){      
        $ftitle = $_POST['ftitle'];
        $field_type = $_POST['field_type'];
        $field_value = $_POST['field_value'];
        //$builder_custom_field = $wpdb->prefix . 'builder_custom_field';
        //$checked = 'no';
        //if(isset($_POST['required_field']) && $_POST['required_field'] != ''){
          //  $checked = $_POST['required_field'];
        //} 
        $wpdb->insert( 
          $builder_custom_field, 
          array(  
            'ftitle' => $ftitle, 
            'field_type' => $field_type, 
            'field_value' => $field_value,
            //'required_field' => $checked,
            'created' => date('Y-m-d H:i:s')
          ),
          array(
            '%s',
            '%s',
            '%s'
          )
        );
    }
    //insert form data end
    ?>
    <button class="toggleformfields btn btn-primary">Add</button>
    <link rel='stylesheet' id='bootstrapcss' href='<?php echo site_url();?>/wp-content/plugins/dight-builder-lead-generation/assets/css/bootstrap.min.css' media='all' />
    <div id="createformfields"class="card">
        <div class="card-header">
            <h4>Create Fields</h4>
        </div>
        <div class="card-body">
            <form action="" method="post">
                <input type="text" id="ftitle" name="ftitle" style="width:100%" placeholder="Enter Title">
                <h5 class="card-title">Select Type of Question</h5>
                <label class="form-check-label" for="inlineRadio1">Dropdown</label>
                <input class="form-check-input" type="radio" name="field_type" id="inlineRadio1" value="Dropdown">
                <label class="form-check-label" for="inlineRadio2">CheckBox</label>
                <input class="form-check-input" type="radio" name="field_type" id="inlineRadio2" value="CheckBox">
                <label class="form-check-label" for="inlineRadio2">RadioButton</label>
                 <input class="form-check-input" type="radio" name="field_type" id="inlineRadio2" value="RadioButton">
                <label class="form-check-label" for="inlineRadio3">Text Box</label>
                <input class="form-check-input" type="radio" name="field_type" id="inlineRadio3" value="TextBox">
                
                </br>
                </br>
                <input type="text" id="field_value" name="field_value" style="width:100%" placeholder="ABC, XYZ, PQR">
                </br>
                <!--<input type="checkbox" class="form-check-input" id="required_field" value="yes" name="required_field">
                 <label class="form-check-label">If You want to required this field please check it.</label>-->
                </br>
                <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Save</button>
            </form>
        </div>
    </div>
    <div class="container-fluid mpcf">
                <div class="box">
                <h4>All Record</h4>
                <div class="requestresponse" style="display:none;"></div>
                <table id="table_id" class="table table-striped table-bordered" style="width:100%">
                    <thead>             
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Field Type</th>
                            <th>Field Value</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $queryleadgeneration = 'SELECT * FROM '.$builder_custom_field;
                        $getleadgeneration = $wpdb->get_results($queryleadgeneration);
                        if(!empty($getleadgeneration)){
                        foreach ($getleadgeneration as $row) { ?>
                            <tr>
                                <td><?php echo $row->id; ?></td>
                                <td><?php echo $row->ftitle; ?></td>
                                <td><?php echo $row->field_type; ?></td>
                                <td><?php echo $row->field_value; ?></td>
                                <td><a class="editprimaryform" rel="<?php echo $row->id; ?>" href="<?php echo admin_url('admin.php?page=edit-fbuilder-form-field&id='.$row->id); ?>"> Edit</a> |<span class="removeformfield" rel="<?php echo $row->id; ?>"> Delete</span> </td>
                            </tr>
                        <?php }} ?>
                    </tbody>                  
                </table> 
        </div>
    </div>
<?php
    echo ob_get_clean();
}

/* delete category form */
add_action( 'wp_ajax_dight_fbuilder_deletecombineform', 'dight_fbuilder_deletecombineform' );
add_action( 'wp_ajax_nopriv_dight_fbuilder_deletecombineform', 'dight_fbuilder_deletecombineform' );
function dight_fbuilder_deletecombineform() {
    global $wpdb;
    $formid = $_POST['formid'];
    if($formid){
        $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_combinedforms';
        $id = $formid;
        $wpdb->delete( $builder_custom_field, array( 'id' => $id ) );
        $message = 'success';
    }else{
        $message = 'error';
    }
    echo json_encode($message);
    wp_die();
}

/* delete category form */
add_action( 'wp_ajax_dight_fbuilder_deletecategoryform', 'dight_fbuilder_deletecategoryform' );
add_action( 'wp_ajax_nopriv_dight_fbuilder_deletecategoryform', 'dight_fbuilder_deletecategoryform' );
function dight_fbuilder_deletecategoryform() {
    global $wpdb;
    $formid = $_POST['formid'];
    if($formid){
        $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_category_form';
        $id = $formid;
        $wpdb->delete( $builder_custom_field, array( 'id' => $id ) );
        $message = 'success';
    }else{
        $message = 'error';
    }
    echo json_encode($message);
    wp_die();
}

/* delete primary form */
add_action( 'wp_ajax_dight_fbuilder_deleteprimaryform', 'dight_fbuilder_deleteprimaryform' );
add_action( 'wp_ajax_nopriv_dight_fbuilder_deleteprimaryform', 'dight_fbuilder_deleteprimaryform' );
function dight_fbuilder_deleteprimaryform() {
    global $wpdb;
    $formid = $_POST['formid'];
    if($formid){
        $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_primary_form';
        $id = $formid;
        $wpdb->delete( $builder_custom_field, array( 'id' => $id ) );
        $message = 'success';
    }else{
        $message = 'error';
    }
    echo json_encode($message);
    wp_die();
}

/* delete form fields */
add_action( 'wp_ajax_dight_fbuilder_deleteformfield', 'dight_fbuilder_deleteformfield' );
add_action( 'wp_ajax_nopriv_dight_fbuilder_deleteformfield', 'dight_fbuilder_deleteformfield' );
function dight_fbuilder_deleteformfield()
{
    global $wpdb;
    $formid = $_POST['formid'];
    if($formid){
        $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';
        $id = $formid;
        $wpdb->delete( $builder_custom_field, array( 'id' => $id ) );
        $message = 'success';
    }else{
        $message = 'error';
    }
    echo json_encode($message);
    wp_die();
}

// edit combine form
function edit_fbuilder_combine_form()
{
    global $wpdb;
    $id = $_REQUEST['id'];
    $dight_fbuilder_combinedforms = $wpdb->prefix . 'dight_fbuilder_combinedforms';
    $dight_fbuildercombinedforms = 'SELECT * FROM '.$dight_fbuilder_combinedforms. ' WHERE `id`='.$id;
    $dight_fbuildercombinedforms = $wpdb->get_results($dight_fbuildercombinedforms);
    //echo '<pre>';
    //print_r($dight_fbuildercombinedforms);
    $dight_fbuilder_primary_form = $wpdb->prefix.'dight_fbuilder_primary_form';
    $getprimaryforms = 'SELECT * FROM '.$dight_fbuilder_primary_form;
    $getresultprimary = $wpdb->get_results($getprimaryforms);

    $dight_fbuilder_category_form = $wpdb->prefix.'dight_fbuilder_category_form';
    $getcatforms = 'SELECT * FROM '.$dight_fbuilder_category_form;
    $getresultcat = $wpdb->get_results($getcatforms);

    if (isset( $_POST['submit'])){  
        $ftitle = $_POST['cattitle'];
        $primaryform_id = $_POST['field_type'];
        $field_value = $_POST['field_value'];
        $wpdb->update( 
            $dight_fbuilder_combinedforms, 
            array( 
                'form_title' => isset($_POST['cattitle'])?$_POST['cattitle']:'',
                'check_splash' => isset($data['check_splash'])?$data['check_splash']:'', 
                'primaryform_id' => isset($_POST['primaryform'])?$_POST['primaryform']:'', 
                'categoryform_id' => isset($_POST['catform'])?json_encode($_POST['catform']):'',
                'shortcode' => '[fbuilder_lead_gen id="'.$id.'" splash="'.$data['check_splash'].'" primaryform_id="'.$_POST['primaryform'].'" catformsid="'.implode(',',$_POST['catform']).'"]',
                'modified' => date('Y-m-d H:i:s')
            ), 
            array( 'id' => $id )
        );
        //wp_redirect( 'admin.php?page=fbuilder-manage-primary-form');
        wp_redirect(
            esc_url_raw(
                add_query_arg(
                    array(
                        'info'     => 'success',
                        'response' => 'success',
                    ),
                    'admin.php?page=fbuilder-combine-form'  
                )
            )
        );
        exit;
    }

    //get db fields data for mapping fields
    $form_fields = $wpdb->prefix.'dight_fbuilder_custom_field';
    $p_fieldids = $wpdb->get_row('SELECT * FROM '.$dight_fbuilder_primary_form.' where id = '.$dight_fbuildercombinedforms[0]->primaryform_id);
    $fieldsIds = json_decode($p_fieldids->field_id);
    $fields = [];
    foreach($fieldsIds as $fieldsId) {
        $fields[] = $wpdb->get_row('SELECT * FROM '.$form_fields.' where id = '.$fieldsId);
    }
    
    $cat_fields = json_decode($dight_fbuildercombinedforms[0]->categoryform_id);
    foreach($cat_fields as $cat_field){
        $s_fields = $wpdb->get_row('SELECT * FROM '.$dight_fbuilder_category_form.' where id = '.$cat_field);
        $s_fieldsIds = json_decode($s_fields->field_id);
        foreach($s_fieldsIds as $s_fieldsId) {
            if(!in_array($s_fieldsId, $fieldsIds)){
                $fields[] = $wpdb->get_row('SELECT * FROM '.$form_fields.' where id = '.$s_fieldsId);
            }            
        }
    }
    
    $webooks = [
        'Key'=>'Key',
        'API_Action' => 'API_Action',
        'Mode' => 'Mode',
        'Cost' => 'Cost',
        'Lead_ID' => 'Lead_ID',
        'Allowed_Times_Sold' => 'Allowed_Times_Sold',
        'Return_Hash_Type' => 'Return_Hash_Type',
        'Return_Hash_Value_Type' => 'Return_Hash_Value_Type',
        'Skip_Partner_ID' => 'Skip_Partner_ID',
        'Return_Best_Price' => 'Return_Best_Price',
        'SRC_ID' => 'SRC_ID',
        'TYPE' => 'TYPE',
        'Test_Lead' => 'Test_Lead',
        'Skip_XSL' => 'Skip_XSL',
        'Match_With_Partner_ID' => 'Match_With_Partner_ID',
        'Redirect_URL' => 'Redirect_URL',
        'IP_Address' => 'IP_Address',
        'SRC' => 'SRC',
        'Landing_Page' => 'Landing_Page',
        'Sub_ID' => 'Sub_ID',
        'Pub_ID' => 'Pub_ID',
        'Optout' => 'Optout',
        'Unique_Identifier' => 'Unique_Identifier',
        'User_Agent' => 'User_Agent',
        'TCPA_Consent' => 'TCPA_Consent',
        'TCPA_Language' => 'TCPA_Language',
        'Trusted_Form_URL' => 'Trusted_Form_URL',
        'LeadiD_Token' => 'LeadiD_Token',
        'First_Name' => 'First_Name',
        'Last_Name' => 'Last_Name',
        'Address' => 'Address',
        'City' => 'City',
        'State' => 'State',
        'Zip' => 'Zip',
        'Primary_Phone' => 'Primary_Phone',
        'Secondary_Phone' => 'Secondary_Phone',
        'Email' => 'Email',
        'Sunroom_Type' => 'Sunroom_Type',
        'Financing' => 'Financing',
        'Process_Of_Moving' => 'Process_Of_Moving',
        'Central_AC_Install_Project_Type' => 'Central_AC_Install_Project_Type',
        'Garage_Door_Type' => 'Garage_Door_Type',
        'Project' => 'Project',
        'Homeowner' => 'Homeowner',
        'Waterproofing_Basement_Type' => 'Waterproofing_Basement_Type',
        'Concrete_Leveling_Type' => 'Concrete_Leveling_Type' ,
        'Tree_Trimming_Type' => 'Tree_Trimming_Type',
        'Emergency' => 'Emergency',
        'Location' => 'Location' ,
        'Timing' => 'Timing' ,
        'Status_For_This_Project' => 'Status_For_This_Project',
        'HVAC_Type' => 'HVAC_Type',
        'Number_Of_Windows' => 'Number_Of_Windows',
        'Roof_Type' => 'Roof_Type',
        'Flooring' => 'Flooring',
        'Sinks' => 'Sinks' ,
        'Countertops' => 'Countertops',
        'Cabinets_Vanity' => 'Cabinets_Vanity',
        'Toilet' => 'Toilet' ,
        'Shower_Bath' => 'Shower_Bath',
        'Bathroom_Remodel' => 'Bathroom_Remodel',
        'Kitchen_Floorplan' => 'Kitchen_Floorplan',
        'Kitchen_Cabinets' => 'Kitchen_Cabinets',
        'Kitchen_Appliances' => 'Kitchen_Appliances',
        'Lighting' => 'Lighting',
        'Gutter_Project_Type' => 'Gutter_Project_Type',
        'Credit_Rating' => 'Credit_Rating',
        'Comments' => 'Comments'
    ];
    
    //save map data to DB
    if(isset($_POST['map_save']) && $_POST['map_save'] != ''){
        //echo'<pre>';print_r($_POST);die('tes');
        $form_id = $_POST['combine_formId'];
        $map_data = $_POST['webhook_field'];
        $map_data = json_encode($map_data, true);
        $update = $wpdb->update( 
            $dight_fbuilder_combinedforms, 
            array( 
                'map_fields' => $map_data,
                'modified' => date('Y-m-d H:i:s')
            ), 
            array( 'id' => $form_id )
        );
    }

    $dight_getmap = 'SELECT * FROM '.$dight_fbuilder_combinedforms. ' WHERE `id`='.$id;
    $dight_fbuildergetmap = $wpdb->get_results($dight_getmap);
    $map_fields = [];
    if(isset($dight_fbuildergetmap[0]->map_fields)){
        $map_fields = $dight_fbuildergetmap[0]->map_fields;
        $map_fields = json_decode($map_fields);
    }
    //echo '<pre>';
    //print_r($map_fields);
?>
 <link rel='stylesheet' id='bootstrapcss' href='<?php echo site_url();?>/wp-content/plugins/dight-builder-lead-generation/assets/css/bootstrap.min.css' media='all' />
    <div class="container">
        <div id="createformfield">
            <div class="card" >
                <div class="card-header">
                    <h4>Edit Combined Form</h4>
                </div>
                <div class="requestresponse" style="display:none;"></div>
                <div class="card-body">
                    <form action="" method="post">
                        <input type="text" id="cattitle" name="cattitle" style="width:100%" placeholder="Form Name" value="<?php echo $dight_fbuildercombinedforms[0]->form_title; ?>">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="row">
                                        <h5 class="card-title">Select Primary Form</h5>
                                        <select id="cat_title" name="primaryform"  class="selectpicker form-control" multiple data-live-search="true" aria-label=" select option">                                         
                                            <?php
                                            if(!empty($getresultprimary)){
                                                foreach($getresultprimary as $getresult_primary){
                                                    $selected = '';
                                                    if($dight_fbuildercombinedforms[0]->primaryform_id == $getresult_primary->id){
                                                        $selected = 'selected="selected"';
                                                    }
                                                    echo '<option value="'.$getresult_primary->id.'" '.$selected.'>'.$getresult_primary->primaryform.'</option>';
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="row">
                                        <h5 class="card-title">Select Category Form</h5>
                                        <select id="cat_title" name="catform[]"  class="selectpicker form-control" multiple data-live-search="true" aria-label=" select option">
                                            <?php
                                            if(!empty($getresultcat)){
                                                $jsondecode = json_decode($dight_fbuildercombinedforms[0]->categoryform_id);
                                                foreach($getresultcat as $getresult_category){
                                                    $selected = '';
                                                    if(in_array($getresult_category->id,$jsondecode)){
                                                        $selected = 'selected="selected"';
                                                    }
                                                    echo '<option value="'.$getresult_category->id.'" '.$selected.'>'.$getresult_category->categoryname.'</option>';
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </br>
                        </br>
                        <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Save</button>
                    </form>
                </div>
            </div>
            <div class="card" >
                <div class="card-header">
                    <h4>Map Combine Form fields with Webhook</h4>
                </div>
                <div class="requestresponse" style="display:none;"></div>
                <div class="card-body">
                    <form action="" method="post" name="map_form_fields">
                        <input type="hidden" name="combine_formId" value="<?php echo $id;?>">
                        <div class="container-fluid">
                            <div class="row">
                                <table class="table" style="width:60%">
                                    <thead>
                                        <tr>
                                            <th>Form Fields</th>
                                            <th>Webhook Fields</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $count = 1;
                                            $jsondecode = json_decode($dight_fbuildercombinedforms[0]->categoryform_id);
                                            foreach ($fields as $k => $field) { 
                                        ?>
                                            <tr>
                                                <td><input type="text" name="form_fields[<?php echo $field->id;?>]" id="" value="<?php echo $field->ftitle;?>" readonly></td>
                                                <td>
                                                    <select name="webhook_field[ff_<?php echo $field->id;?>]" id="">
                                                    <?php foreach($webooks as $key=>$val) { ?>
                                                        <option value="<?php echo $key;?>"><?php echo $val;?></option>
                                                    <?php } ?>
                                                    </select>
                                                </td>
                                            </tr>
                                        <?php $count++;
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        </br>
                        </br>
                        <button type="submit" value="Submit" class="btn btn-primary" name="map_save">Map Fields</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// edit form fields
function edit_fbuilder_form_field()
{
    global $wpdb;
    $id = $_REQUEST['id'];
    $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';
    $custom_getfields = 'SELECT * FROM '.$builder_custom_field.' WHERE `id` = '.$id;
    $custom_getfields = $wpdb->get_results($custom_getfields);
    //$req_fiels = $custom_getfields[0]->required_field;
    if (isset( $_POST['submit'])){  
        
        $ftitle = $_POST['ftitle'];
        $field_type = $_POST['field_type'];
        $field_value = $_POST['field_value'];
        //$required_field = $_POST['required_field'];
        $wpdb->update( 
            $builder_custom_field, 
            array( 
                'ftitle' => $ftitle, 
                'field_type' => $field_type, 
                'field_value' => $field_value,
            ), 
            array( 'id' => $id )
        );        
        //wp_redirect( 'admin.php?page=fbuilder-manage-primary-form');
        wp_redirect(
            esc_url_raw(
                add_query_arg(
                    array(
                        'info'     => 'success',
                        'response' => 'success',
                    ),
                    'admin.php?page=dight-fbuilder-create-form'  
                )
            )
        );
        exit;
    }
    $Dropdown = '';
    $CheckBox = '';
    $TextBox = '';
    $RadioButton ='';
    if(isset($custom_getfields[0]->field_type) && $custom_getfields[0]->field_type == 'Dropdown'){
        $Dropdown = 'checked';
    }else if(isset($custom_getfields[0]->field_type) && $custom_getfields[0]->field_type == 'CheckBox'){
        $CheckBox = 'checked';
    }else if(isset($custom_getfields[0]->field_type) && $custom_getfields[0]->field_type == 'TextBox'){
        $TextBox = 'checked';
    }else if(isset($custom_getfields[0]->field_type) && $custom_getfields[0]->field_type == 'RadioButton'){
        $RadioButton = 'checked';
    }

    ?>
    <div class="card" >
        <div class="card-header">
            <h4>Create Fields</h4>
        </div>
        <div class="card-body">
            <form action="" method="post">
                <input type="text" id="ftitle" name="ftitle" style="width:100%" placeholder="Enter Title" value="<?php echo isset($custom_getfields[0]->ftitle)?$custom_getfields[0]->ftitle:''; ?>">
                <h5 class="card-title">Select Type of Question</h5>
                <label class="form-check-label" for="inlineRadio2">CheckBox</label>
                <input class="form-check-input" type="radio" name="field_type" id="inlineRadio1" value="CheckBox" <?php echo $CheckBox; ?>>
                 <label class="form-check-label" for="inlineRadio3">Text Box</label>
                <input class="form-check-input" type="radio" name="field_type" id="inlineRadio2" value="TextBox" <?php echo $TextBox; ?>>
                <label class="form-check-label" for="inlineRadio2">RadioButton</label>
                <input class="form-check-input" type="radio" name="field_type" id="inlineRadio2" value="RadioButton" <?php echo $RadioButton; ?>>
               <label class="form-check-label" for="inlineRadio1">Dropdown</label>
                <input class="form-check-input" type="radio" name="field_type" id="inlineRadio3" value="Dropdown" <?php echo $Dropdown; ?>>
                
                </br>
                </br>
                <input type="text" id="field_value" name="field_value" style="width:100%" placeholder="ABC, XYZ, PQR" value="<?php echo isset($custom_getfields[0]->ftitle)?$custom_getfields[0]->field_value:''; ?>">
                </br>
              <!--  <input type="checkbox" class="form-check-input" <?php echo ($req_fiels == 'yes' ? 'checked' : ''); ?> id="required_field" value="yes" name="required_field">
                 <label class="form-check-label">If You want to required this field please check it.</label>-->
                </br>
                <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Save</button>
            </form>
        </div>
    </div>
    <?php
}
// edit category form
function edit_fbuilder_category_form(){
    global $wpdb;
    $id = $_REQUEST['id'];
    //require_once('classes/manage_primary_categoryform.php' );
    //$builderprimaryandcatform = new dight_fbuilder_primaryandcatform();
    //echo $builderprimaryandcatform->dight_fbuilder_primaryformedit($id);
    $dight_fbuilder_primary_form = $wpdb->prefix . 'dight_fbuilder_category_form';
    $getfields = 'SELECT * FROM '.$dight_fbuilder_primary_form.' WHERE `id` = '.$id;
    $getresults = $wpdb->get_results($getfields);
    $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';
    $custom_getfields = 'SELECT * FROM '.$builder_custom_field;
    $custom_getfields = $wpdb->get_results($custom_getfields);
    $options = '';
    if(!empty($getresults)){
        $formfields = json_decode($getresults[0]->field_id);
        if(!empty($formfields)){
            if(!empty($custom_getfields && isset($custom_getfields[0]->id))){
                foreach($custom_getfields as $getresult)
                {
                    $selected = '';
                    if(in_array($getresult->id,$formfields)){
                        $selected = 'selected';
                    }
                    $options .= '<option value="'.$getresult->id.'" '.$selected.'>'.$getresult->ftitle.'</option>';
                }
            }
        }else{
           if(!empty($custom_getfields && isset($custom_getfields[0]->id))){
                foreach($custom_getfields as $getresult)
                {
                    $options .= '<option value="'.$getresult->id.'">'.$getresult->ftitle.'</option>';
                }
            }
        }
    }
    if (isset( $_POST['submit'])){  
        $formfields = $_POST['formfields'];
        $cattitle = $_POST['cattitle'];
        $wpdb->update( 
            $dight_fbuilder_primary_form, 
            array( 
                'field_id' => json_encode($formfields),
                'categoryname' => $cattitle,
                'modified' => date('Y-m-d H:i:s')
            ), 
            array( 'id' => $id )
        );
        //wp_redirect( 'admin.php?page=fbuilder-manage-primary-form');
        wp_redirect(
            esc_url_raw(
                add_query_arg(
                    array(
                        'info'     => 'success',
                        'response' => 'success',
                    ),
                    'admin.php?page=fbuilder-manage-cat-and-questions'  
                )
            )
        );
        exit;
    }
?>
 <link rel='stylesheet' id='bootstrapcss' href='<?php echo site_url();?>/wp-content/plugins/dight-builder-lead-generation/assets/css/bootstrap.min.css' media='all' />
    <div class="card" >
        <div class="card-header">
            <h4>Manage Categories</h4>
        </div>
        <div class="requestresponse" style="display:none;"></div>
        <div class="card-body">
            <form action="" method="post">
                <input type="text" id="cattitle" name="cattitle" style="width:100%" placeholder="Enter Title" value="<?php echo isset($getresults[0]->categoryname)?$getresults[0]->categoryname:'' ?>">
                <h5 class="card-title">Select Questions</h5>
                <select id="cat_title" name="formfields[]"  class="selectpicker form-control" multiple data-live-search="true" aria-label=" select option">
                   <?php echo $options; ?>
                </select>
                </br>
                </br>
                <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Update</button>
            </form>
        </div>
    </div>
<?php
}
function edit_fbuilder_primary_form() {
    global $wpdb;
    $id = $_REQUEST['id'];
    //require_once('classes/manage_primary_categoryform.php' );
    //$builderprimaryandcatform = new dight_fbuilder_primaryandcatform();
    //echo $builderprimaryandcatform->dight_fbuilder_primaryformedit($id);
    $dight_fbuilder_primary_form = $wpdb->prefix . 'dight_fbuilder_primary_form';
    $getfields = 'SELECT * FROM '.$dight_fbuilder_primary_form.' WHERE `id` = '.$id;
    $getresults = $wpdb->get_results($getfields);
    $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';
    $custom_getfields = 'SELECT * FROM '.$builder_custom_field;
    $custom_getfields = $wpdb->get_results($custom_getfields);
    $options = '';
    if(!empty($getresults)){
        $formfields = json_decode($getresults[0]->field_id);
        if(!empty($formfields)){
            if(!empty($custom_getfields && isset($custom_getfields[0]->id))){
                foreach($custom_getfields as $getresult)
                {
                    $selected = '';
                    if(in_array($getresult->id,$formfields)){
                        $selected = 'selected';
                    }
                    $options .= '<option value="'.$getresult->id.'" '.$selected.'>'.$getresult->ftitle.'</option>';
                }
            }
        }else{
           if(!empty($custom_getfields && isset($custom_getfields[0]->id))){
                foreach($custom_getfields as $getresult)
                {
                    $options .= '<option value="'.$getresult->id.'">'.$getresult->ftitle.'</option>';
                }
            }
        }
    }
    if (isset( $_POST['submit'])){  
        $formfields = $_POST['formfields'];
        $cattitle = $_POST['cattitle'];
        $slidedropdown = $_POST['slidedropdown'];
        $wpdb->update( 
            $dight_fbuilder_primary_form, 
            array( 
                'field_id' => json_encode($formfields),
                'primaryform' => $cattitle,
                'slidedropdown' => $slidedropdown,
                'modified' => date('Y-m-d H:i:s')
            ), 
            array( 'id' => $id )
        );
        //wp_redirect( 'admin.php?page=fbuilder-manage-primary-form');
        wp_redirect(
            esc_url_raw(
                add_query_arg(
                    array(
                        'info'     => 'success',
                        'response' => 'success',
                    ),
                    'admin.php?page=fbuilder-manage-primary-form'  
                )
            )
        );
        exit;
    }
    ?>
    <div class="card" >
        <div class="card-header">
            <h4>Manage Primary form</h4>
        </div>
        <div class="requestresponse" style="display:none;"></div>
        <div class="card-body">
            <form action="" method="post">
                <input type="text" id="cattitle" name="cattitle" style="width:100%" placeholder="Enter Title" value="<?php echo isset($getresults[0]->primaryform)?$getresults[0]->primaryform:'' ?>">
                <h5 class="card-title">Select Questions</h5>
                <select id="cat_title"  name="formfields[]" class="selectpicker form-control" multiple data-live-search="true" aria-label=" select option">
                   <?php echo $options; ?>
                </select>
                <div class="dropdownoptions">
                    <?php
                    $front = '';
                    $end = '';
                    if($getresults[0]->slidedropdown == 'front'){
                        $front = 'checked';
                    }
                    if($getresults[0]->slidedropdown == 'end'){
                        $end = 'checked';
                    }
                    ?>
                    Would you like to display dropdown in the start of form or in the end ?
                    <input type="radio" name="slidedropdown" value="front" <?php echo $front;?>>In the start
                    <input type="radio" name="slidedropdown" value="end" <?php echo $end;?>>In the end
                </div>
                </br>
                </br>
                <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Update</button>
            </form>
        </div>
    </div>
<link rel='stylesheet' id='bootstrapcss' href='<?php echo site_url();?>/wp-content/plugins/dight-builder-lead-generation/assets/css/bootstrap.min.css' media='all' />
<?php
}
function dight_fbuilder_complete_form( $atts) {
    ob_start();
   //
    $splas = $atts['splash'];
    global $wpdb;
    $dight_fbuilder_primary_form = $wpdb->prefix.'dight_fbuilder_primary_form';
    $getprimaryforms = 'SELECT * FROM '.$dight_fbuilder_primary_form.' WHERE id='.$atts['primaryform_id'];
    $getresultprimary = $wpdb->get_results($getprimaryforms);
    if(isset($getresultprimary[0]->field_id) && $getresultprimary[0]->field_id != ''){
        $pri_fieldids = json_decode($getresultprimary[0]->field_id);
        $primary_fieldids = implode(',',$pri_fieldids);
    }
    $table = $wpdb->prefix.'dight_fbuilder_custom_field';
    $query = 'SELECT * FROM '.$table.' WHERE id IN ('.$primary_fieldids.')';
    $dight_fbuilder_custom_field = $wpdb->get_results($query);
    //echo'<pre>';print_r($dight_fbuilder_custom_field);die('tse');
    ?>
    <div style="text-align:center;margin-top:40px;">
        <span class="step"></span>
        <span class="step"></span>
    </div>
<?php
    if($splas == 'yes')
    {
?>
<style>
.imagelogo a img {
    width: 100%;
    border-radius: 98px;
}
.imagelogo {
    width: 200px;
    height: 200px;
    border-radius: 98px;
    text-align: center;
    margin: auto;
}
.imagelogo a img {
    width: 100%;
    border-radius: 121px;
    height: 100%;
}
.textbar {
    max-width: 500px;
    margin: auto;
    text-align: center;
}
.textbar h2 {
    font-size: 30px;
    font-weight: 500;
    color: #000;
    font-family: sans-serif;
}
.textbar p {
    font-size: 16px;
    color: #000;
    font-family: sans-serif;
    padding-bottom: 10px;
}

.form-group.tab label {
    font-size: 18px;
    font-family: sans-serif !important;
    font-weight: 600;
}
div#modal-1-content ul li {
    font-size: 16px;
    font-family: sans-serif;
    font-weight: 600;
    color: #010101;
    text-transform: capitalize;
}
p.wp-block-site-title a {
    font-size: 16px;
    font-weight: 600;
    color: #010101;
    font-family: sans-serif;
}
p.has-text-align-right a {
    font-size: 16px;
    font-family: sans-serif;
    font-weight: 600;
}
p.has-text-align-right {
    font-size: 16px;
    font-weight: 600;
    color: #010101;
    font-family: sans-serif;
}
.buttonbar {
    text-align: end;
}
.next_btn {
    color: #000;
    background-color: #ffffff;
    border-color: #000000;
    padding: 7px 60px;
    font-size: 18px;
    font-family: sans-serif;
    transition: 1.5s;
    border: 2px solid;
}
h1.wp-block-post-title {
    font-size: 32px;
    font-weight: 600;
    text-transform: capitalize;
    font-family: sans-serif;
}
.minpart {
    max-width: 600px;
    margin: auto;
    border: 1px solid;
    padding: 30px 30px;
    border-radius: 10px;
    box-shadow: 0px 0px 8px -2px;
}
.setup {
    padding: 30px 30px;
}
element.style {
}
.colsmae {
    border: 1px solid #716666;
    box-shadow: 0px 0px 8px -2px;
    max-width: 23% !important;
    margin: 10px;
    border-radius: 10px;
    height: 40%;
}
.secondaybox {
    padding: 35px !important;
    box-shadow: 0px 0px 9px 0px;
    background: white;
    border-radius: 10px;
}
input.checkbar[type=checkbox] {
    transform: scale(1.5);
    margin: 0 0 4px;
}
input.checkbar {
    width: 30px;
}
.next_btn {
    color: #000;
    background-color: #ffffff;
    border-color: #000000;
    padding: 7px 60px;
    font-size: 18px;
    font-family: sans-serif;
    transition: 1.5s;
    border: 2px solid;
    border-radius: 5px;
}
.next_btn:hover {
    background: #ffca60;
    border-color: #ffca60;
    border-radius: 5px;
}

/* input.submit.btn.btn-success.secondary_save {
   display: flex;
    float: right;
    margin: 20px;
    position: absolute;
    right: 0;
    bottom: 0;
} */

.botton_pass {
    padding-bottom: 20px;
}

body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
    max-width: 100% !important;
}
</style>
<style>
 @media screen and (min-width: 320px) and (max-width: 767px) { 

.setup {
    padding: 0px!important;
} 
.textbar h2 {
    font-size: 18px !important;
} 
.textbar p {
    font-size: 14px !important;
    padding: 0  !important;
} 
.buttonbar {
    margin-top: 30px; 
}
.next_btn {
    margin: 0 auto;
    display: block;
} 
div#primaryseconday {
    padding-right: 0 !important;
    padding-left: 0 !important;
} 
.colsmae {
    max-width: 100% !important;
    margin: 0px;
    margin-top: 10px;
}

 } 
</style>
<div class="container">
    <div class="row" >
        <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="setup" id="myDIV">
        <div class="minpart">
            <?php
                global $wpdb;
                $dight_fbuilder_splash_forms = $wpdb->prefix . 'dight_fbuilder_splash_forms';
                $queryleadgeneration = 'SELECT * FROM '.$dight_fbuilder_splash_forms;
                $getleadgeneration = $wpdb->get_results($queryleadgeneration);
                if(!empty($getleadgeneration)){
                    $upload_dir = wp_upload_dir();
                    $path = $upload_dir['baseurl'].'/splash/';
                    foreach ($getleadgeneration as $row) {       
            ?>
            <div class="iconimage">
            <div class="imagelogo">
              <a href="" target="_blank">
               <img src="<?php echo $path.''.$row->file; ?>" width="300" height="225" style="border:1px solid black;" />
              </a>
            </div>
            <div class="textbar">
            <h2><?php echo $row->title; ?></h2>
            <p><?php echo $row->description; ?> </p>
        </div>
            <?php } } ?>
        <div class="buttonbar">
        <button type="button" class=" splash-screen-btn next_btn">Next</button>
        <div>
        </div>
    </div>
  </div>
</div>
</div>

<?php } else {
    echo 'ddsf';
}
?>
<style>
.promessage {
    padding: 30px;
    box-shadow: 0px 0px 8px -2px;
    border-radius: 10px;
}
.klop {
    text-align: end;
}
.textheading {
    font-size: 24px;
    font-weight: 600;
    padding-bottom: 15px;
    font-family: sans-serif;
    color: #000;
}
span.check_count {
    font-size: 16px;
    text-transform: capitalize;
    padding-left: 5px;
    font-family: sans-serif;
    color: #000;
}
input.form-check-input {
    width: 17px;
    height: 17px;
}
label {
    font-size: 18px;
    font-family: sans-serif;
    font-weight: 600;
}
p.legal_dis {
    font-size: 16px;
    font-family: sans-serif;
    padding-bottom: 30px;
}


</style>
<div class="container" id="primaryseconday" style="display:none;">
  <div class="promessage">
          <!--<div class="progress">

          <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>

        </div>-->
        <form id="fbuilder_combine_form" action="#"  method="post" class="was-validated">
            <input type="hidden" name="form_id" value="<?php echo $atts['id'];?>" />
            <input type="hidden" name="primary_form_id" value="<?php echo $atts['primaryform_id'];?>" />
    <?php
        $dight_fbuilder_setings_form = $wpdb->prefix.'dight_fbuilder_setting_forms';
        $getsetingforms = 'SELECT * FROM '.$dight_fbuilder_setings_form.'';
        $getresultset = $wpdb->get_results($getsetingforms);
        $legal_disclamer = $getresultset[0]->legal_disclamer;
        if(!empty($dight_fbuilder_custom_field)){
            $dight_fbuildercustomfield = array_chunk($dight_fbuilder_custom_field,1);
            
            $formfields = [];
            foreach($dight_fbuildercustomfield as $dightfbuildercustomfield)
            {
                foreach($dightfbuildercustomfield as $getresult_primary){ 
                    if( $getresult_primary->field_type == 'TextBox')
                    {
                         $formfields['otherfields'][]= $getresult_primary;
                    }else{
                         $formfields['TextBox'][]= $getresult_primary;
                    }
                }
            }
            $outarray = array_chunk($formfields['otherfields'],4);
            
            if(isset($formfields['TextBox'])){
                $Dropdown_field = array_chunk($formfields['TextBox'],1);
                if($getresultprimary[0]->slidedropdown == 'front'){
                    $outarray = array_merge((array)$Dropdown_field, (array)$outarray);
                }
                if($getresultprimary[0]->slidedropdown == 'end'){
                    $outarray = array_merge((array)$outarray, (array)$Dropdown_field);
                }
            }
            //$firstmerge = array_merge($dightfbuildercustom_field,$formfields['Dropdown']);
            
            //echo '<pre>';
            //print_r($outarray);
            
            $parentcount =  count($outarray);
            $count = 1;
            foreach($outarray as $getresultprimary){                
                echo '<fieldset>';
                foreach($getresultprimary as $getresult_primary){ 
                    //echo'<pre>';print_r($getresult_primary);die('tets');
                    //$reqi_field = $getresult_primary->required_field;                   
                    if( $getresult_primary->field_type == 'TextBox') { ?>
                    <div class="form-group tab">
                        <label for="text"><?php echo $getresult_primary->ftitle; ?></label>
                        <input type="text" class="form-control" name="ff_<?php echo $getresult_primary->id; ?>" required placeholder="">
                    </div> 
                <?php } elseif($getresult_primary->field_type == 'RadioButton') { ?>

                    <div class="form-group tab">
                        <label for="checkbox"><?php echo $getresult_primary->ftitle; ?></label><br>
                        <?php $checks = explode(',',$getresult_primary->field_value);
                              $k = 1;
                            foreach($checks as $check ){?>
                                <input class="form-check-input" type="radio" name="ff_<?php echo $getresult_primary->id?>[]" value="<?php echo $check; ?>">
                                <span class="check_count"><?php echo $check; ?></span><br>
                        <?php $k++; 
                        } ?>
                    </div> 


                <?php } elseif($getresult_primary->field_type == 'CheckBox') { ?>
                    <div class="form-group tab">
                        <label for="checkbox"><?php echo $getresult_primary->ftitle; ?></label><br>
                        <?php $checks = explode(',',$getresult_primary->field_value);
                              $k = 1;
                            foreach($checks as $check ){?>
                                <input class="form-check-input" type="checkbox" name="ff_<?php echo $getresult_primary->id?>[]" value="<?php echo $check; ?>">
                                <span class="check_count"><?php echo $check; ?></span><br>
                        <?php $k++; 
                        } ?>
                    </div>
                <?php } elseif($getresult_primary->field_type == 'Dropdown') {
                        $dropdownexplode = explode(',',$getresult_primary->field_value);?>
                    <div class="form-group tab">
                        <label for="dropdown"><?php echo $getresult_primary->ftitle; ?></label>
                        <select class="form-control dropdownselect" required name="ff_<?php echo $getresult_primary->id; ?>[]">
                            <?php
                                foreach($dropdownexplode as $dropdownexplodes){
                            ?>
                                <option value="<?php echo $dropdownexplodes;?>"><?php echo $dropdownexplodes;?></option>
                            <?php } ?>
                        </select>
                    </div>
                <?php
                    }                    
                }                
                ?>
                <div>
                    <label class="disc_lamer" for="text" >Legal Disclamer</label>
                    <p class="legal_dis"><?php echo $legal_disclamer; ?></p>
                </div>
                    <?php
                    if($count > 1){
                        echo '<input type="button" name="password" class="previous next_btn" value="Previous" />';
                    }
                    if($parentcount !== $count){                       
                        echo '<input type="button" name="password" class="next next_btn" value="Next" />';
                    }
                    else
                    {                        
                        echo '<input type="submit" name="submit" class="submit  next_btn" value="Submit" />';
                    }
                    echo '</fieldset>';
                    $count++;
                }
            }
            ?>           
        </form>
    </div>
</div>
    <?php
    $a= $atts['catformsid'];
    $catid = explode(',',$a);
    global $wpdb;
    echo '<div class="container secondaybox" id="secondayprimary" style="display:none;">
    <div class="alert-message success-msg-sec" id="success-msg-sec" style="display:none;"></div>
    <div class="row">';
    $dight_fbuilder_secondary_form = $wpdb->prefix.'dight_fbuilder_category_form';
    if(!empty($catid)){
        foreach($catid as $catids)
        {
            $getsecondaryforms = 'SELECT * FROM '.$dight_fbuilder_secondary_form.' WHERE id='.$catids;
            $getresultsecondary = $wpdb->get_results($getsecondaryforms);
            $dight_fbuilder_setings_form = $wpdb->prefix.'dight_fbuilder_setting_forms';
            $getsetingforms = 'SELECT * FROM '.$dight_fbuilder_setings_form.'';
            $getresultset = $wpdb->get_results($getsetingforms);
            $term_policy = $getresultset[0]->term_policy;
            $enablepolicy = $getresultset[0]->enabledpolicy;
            if(isset($getresultsecondary[0]->field_id) && $getresultsecondary[0]->field_id != ''){
                $fieldids = json_decode($getresultsecondary[0]->field_id);
                $result=array_diff($fieldids,$pri_fieldids);
                $fieldidss = implode(',',$result);
                $table = $wpdb->prefix.'dight_fbuilder_custom_field';
                $query = 'SELECT * FROM '.$table.' WHERE id IN ('.$fieldidss.')';
                $dight_fbuilder_custom_field = $wpdb->get_results($query);
                $count = 1;
                echo '<div class="col-lg-12 col-md-4 col-sm-12 colsmae"><div>
                <form method="post" action="#" class="was-validated" id="secondary_form">
                <input type="hidden" class="lastinsertedid" name="lastinsertedid" id="lastinsertedid" value="">
                <input type="hidden" name="Trusted_Form_URL" value="">';
    ?>
    <label for="text"><h2 class="textheading"><?php echo $getresultsecondary[0]->categoryname; ?></h2></label>
    <input type="hidden" name="subcat_id_<?php echo $catids; ?>" value="<?php echo $catids; ?>">
    <?php
    foreach($dight_fbuilder_custom_field as $getresult_primary) {
        if( $getresult_primary->field_type == 'TextBox') {
    ?>
    <div class="form-group">
        <label for="text"><?php echo $getresult_primary->ftitle; ?></label>
        <input type="text" class="form-control" required name="ff_<?php echo $getresult_primary->id; ?>" placeholder="">
    </div>   
    <?php
    } elseif($getresult_primary->field_type == 'CheckBox') { ?>
        <div class="form-group">
            <label for="checkbox"><?php echo $getresult_primary->ftitle; ?></label>
            <?php $i = 1; $checks = explode(',',$getresult_primary->field_value);
                foreach($checks as $check) { ?>
                    <input class="checkbar" type="checkbox" name="ff_<?php echo $getresult_primary->id; ?>[]" value="<?php echo $check; ?>">
                    <span><?php echo $check; ?></span>
            <?php $i++; } ?>
        </div>
    <?php } elseif($getresult_primary->field_type == 'Dropdown') {
                $dropdownexplode = explode(',',$getresult_primary->field_value); 
    ?>
    <div class="form-group">
        <label for="dropdown"><?php echo $getresult_primary->ftitle; ?></label>
        <select class="form-control dropdownselect" required name="ff_<?php echo $getresult_primary->id; ?>">
            <?php
                foreach($dropdownexplode as $dropdownexplodes){
            ?>
                <option value="<?php echo $dropdownexplodes;?>"><?php echo $dropdownexplodes;?></option>
            <?php } ?>
        </select>
    </div>
    <?php }                 
        $count++;
    }
    if($enablepolicy == 'yes') {
    ?>
    <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="myCheck" name="policy" value="policy_<?php echo $enablepolicy; ?>" required>
        <label class="form-check-label" for="exampleCheck1"><?php echo $term_policy; ?></label>
    </div>
    <?php
        }
    ?>
   <div class="botton_pass">
   <input type="submit" name="submit" class="submit  next_btn rctBT" value="Submit" />
   </div>
    </form>
    </div>
    </div>
    <?php
            }
        }
    }
    echo '</div></div>';
?>
<style type="text/css">
    #fbuilder_combine_form fieldset:not(:first-of-type) {
        display: none;
    }
    div#primaryseconday {
        padding-right: 15%;
        padding-left: 15%;
        margin-right: auto;
        margin-left: auto;
    }
</style>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function(){
    $( ".splash-screen-btn" ).click(function() {     
        $('#myDIV').hide();
        $('#primaryseconday').show();       
    });

    $('select.dropdownselect').change(function(){
        $(this).parent().parent().find('.next').trigger('click');  
        //$(".next").one( "click", function() {  } );          
    });
    var current = 1,current_step,next_step,steps;
    steps = $("fieldset").length;
    $(".next").click(function(){
        var ifempty = '';
        $(this).parent().find('input').each(function() {
            var checkempty = $(this).val();
            if(checkempty == ''){
                $(this).css('border','1px solid #a94442');
                ifempty = 'notempty';
                return false;
            }else{
                $(this).css('border','0px solid');
            }
        });
        if(ifempty == ''){
            current_step = $(this).parent();
            next_step = $(this).parent().next();
            next_step.show();
            current_step.hide();
            setProgressBar(++current);
        }
    });
    $(".previous").click(function(){
        current_step = $(this).parent();
        next_step = $(this).parent().prev();
        next_step.show();
        current_step.hide();
        setProgressBar(--current);
    });
    setProgressBar(current);
    function setProgressBar(curStep){
        var percent = parseFloat(100 / steps) * curStep;
        percent = percent.toFixed();
        $(".progress-bar")
        .css("width",percent+"%")
        .html(percent+"%");   
    }
    function gtag(){
        gtag('event', 'conversion', {'send_to': 'AW-787450894/UTZXCPOatcQDEI6YvvcC'});
    }
    $("#fbuilder_combine_form").submit(function(e) {
        e.preventDefault(); 
        var ajax_url = '<?php echo admin_url('admin-ajax.php'); ?>';
        var formdata = $(this).serialize();
        var data = {
            'action': 'dight_fbuilder_combinedform_save',
            'formdata':formdata,
        };
        $.ajax({
            type: 'post',
            url:ajax_url,
            data: data,
            dataType: 'json',
            success: function(response){
                if(response.message == 'success'){
                    $('.success-msg-sec').html(' ');
                    $('.lastinsertedid').val(response.lastid );
                    $('#primaryseconday').hide();
                    $('#secondayprimary').show();
                    setTimeout(function(){
                        $('.success-msg-sec').append('<span>'+response.msg+'</span>');
                        $('.success-msg-sec').show();
                    }, 1500);
                    //jQuery('#2ndForm').css('display', 'block');

                    //setTimeout(function(){

                        //location.reload();

                    //}, 1500);
                } else {
                }
            }
        });
    });

    //secondary form submit
    $("form#secondary_form").submit(function(e) {
        e.preventDefault(); 
        var ajax_url = '<?php echo admin_url('admin-ajax.php'); ?>';
        var formdata_sec = $(this).serialize();
        var trusted_url = $("input[name='xxTrustedFormCertUrl']").val();
        //console.log(formdata_sec);
        var data = {
            'action': 'dight_fbuilder_secondaryform_save',
            'formdata_sec':formdata_sec,
            'trusted_url':trusted_url
        };
        $.ajax({
            type: 'post',   
            url:ajax_url,
            data: data,
            dataType: 'json',
            success: function(response){
                if(response.message == 'success'){
                    //$("#secondayprimary").load(" #secondayprimary > *");
                    //gtag();
                    //jQuery('#2ndForm').css('display', 'block');
                    $('.success-msg-sec').html(' ');
                    setTimeout(function(){
                        //location.reload();
                        $('.success-msg-sec').append('<span>'+response.msg+'</span>');
                        $('.success-msg-sec').show();
                    }, 1500);
                }else{
                }
            }
        });
    });
});
</script>
<script type="text/javascript">
(function() {
var tf = document.createElement('script');
tf.type = 'text/javascript'; tf.async = true;
tf.src = ("https:" == document.location.protocol ? 'https' : 'http') + "://api.trustedform.com/trustedform.js?field=xxTrustedFormCertUrl&ping_field=xxTrustedFormPingUrl&l=" + new Date().getTime() + Math.random();
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(tf, s);
})();
</script>
<noscript>
<img src="https://api.trustedform.com/ns.gif" />
</noscript>
<?php  
$json = ob_get_clean();
return $json;   
}
add_shortcode('fbuilder_lead_gen', 'dight_fbuilder_complete_form');
add_action( 'wp_ajax_dight_fbuilder_combinedform_save', 'dight_fbuilder_combinedform_save' );
add_action( 'wp_ajax_nopriv_dight_fbuilder_combinedform_save', 'dight_fbuilder_combinedform_save' );
function dight_fbuilder_combinedform_save() {
    global $wpdb;
    parse_str($_POST['formdata'], $formdata);    
    if(!empty($formdata)){
        $dight_fbuilder_combine_forms = $wpdb->prefix . 'dight_fbuilder_combine_forms';       
        $form_id = $formdata['primary_form_id']; 
        $formID = $formdata['form_id'];
        $data = json_encode($formdata);
        $wpdb->insert( 
          $dight_fbuilder_combine_forms, 
          array(  
            'form_id' => $formID,
            'form_data' => $data, 
            'created' => date('Y-m-d H:i:s')
          )
        );
        $lastid = $wpdb->insert_id;
        session_start();
        $_SESSION['last_action'] = time();

        $message = 'success';
        $response = [
            'message' => 'success',
            'lastid' => $lastid,
            'msg'    => 'Your Basic Information submitted Successfully!!'
        ];
    }else{
        $response = [
            'message' => 'error',
            'lastid' => ''
        ];
    }
    echo json_encode($response);
    wp_die();
}

//Secondary form submition
add_action( 'wp_ajax_dight_fbuilder_secondaryform_save', 'dight_fbuilder_secondaryform_save' );
add_action( 'wp_ajax_nopriv_dight_fbuilder_secondaryform_save', 'dight_fbuilder_secondaryform_save' );
function dight_fbuilder_secondaryform_save() {
    global $wpdb;
    parse_str($_POST['formdata_sec'], $formdata_sec); 
    session_start();
    $trusted_url = $_POST['trusted_url'];
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    $length = 15;
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[random_int(0, $charactersLength - 1)];
    }
    
    if(isset( $_POST['formdata_sec'] )){
        $dight_fbuilder_combine_forms = $wpdb->prefix . 'dight_fbuilder_combine_forms';   
        //$data = json_encode($formdata_sec);
        $id = $formdata_sec['lastinsertedid'];
        $dight_fbuilder_combine_form_update = $wpdb->prefix . 'dight_fbuilder_combine_forms';
        $getrecords = 'SELECT * FROM '.$dight_fbuilder_combine_form_update.' WHERE `id` = '.$id;
        $getresults = $wpdb->get_row($getrecords);
        $primary_data = $getresults->form_data;
        $primary_data = json_decode($primary_data, true);
        $merge_array = array_merge($primary_data, $formdata_sec);
        $merge_data = json_encode($merge_array);
        //echo'<pre>';print_r($_SESSION);die('tet');
        $wpdb->update( 
          $dight_fbuilder_combine_forms, 
          array(  
            'form_data' => $merge_data, 
            'nonce' => $randomString,
            'modified' => date('Y-m-d H:i:s')
          ),
          array( 'id' => $id )
        );
        
        $api_table = $wpdb->prefix . 'dight_fbuilder_combinedforms';
        $rows = $wpdb->get_row('SELECT * FROM '.$api_table.' WHERE `id` = '.$getresults->form_id);
        $api_data = json_decode($rows->map_fields, true);
        $webdata = [];
        foreach($merge_array as $k=>$v){
            foreach( $api_data as $api=>$val ){
                if( $api == $k ){
                    $webdata[$val] = $v;
                }
            }
        }
        function get_client_ip() {
            $ipaddress = '';
            if (isset($_SERVER['HTTP_CLIENT_IP']))
                $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
            else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
                $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
            else if(isset($_SERVER['HTTP_X_FORWARDED']))
                $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
            else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
                $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
            else if(isset($_SERVER['HTTP_FORWARDED']))
                $ipaddress = $_SERVER['HTTP_FORWARDED'];
            else if(isset($_SERVER['REMOTE_ADDR']))
                $ipaddress = $_SERVER['REMOTE_ADDR'];
            else
                $ipaddress = 'UNKNOWN';
            return $ipaddress;
        }
        $required_data = [
            'Key' => '1857655264f51003b62d59b0f523e5bf4692f97f2f8c08bcba236df68b7e7225',
            'API_Action' => 'pingPostLead',
            'Mode' => 'full',
            'SRC' => 'Windows_Form_0001',
            'TYPE' => '18',
            'Landing_Page' => 'landing',
            'Project' => 'Windows Replace - Multiple',
            'Homeowner' => 'Yes',
            'IP_Address' => get_client_ip(),
            'Zip'   => '99547',
            'Trusted_Form_URL'  => $trusted_url
        ];
        $web_merge = array('Request'=> array_merge($required_data, $webdata));
        $postFields = json_encode($web_merge);
        //

        $expireAfter = 1;
        if(isset($_SESSION['last_action'])){
            $inactiveTime = time() - $_SESSION['last_action'];
            $expireAfterSeconds = $expireAfter * 60;
                if($inactiveTime >= $expireAfterSeconds){
                    echo'sessionexpires';
                    session_unset();
                    session_destroy();
                    /* webhook api starts */
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                        CURLOPT_URL => "https://cealeads.leadportal.com/apiJSON.php",
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $postFields,
                        CURLOPT_HTTPHEADER => array(
                            "cache-control: no-cache",
                            "content-type: application/json",
                        ),
                    ));
                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    curl_close($curl);
                    if ($err) {
                        echo "cURL Error #:" . $err;
                    } else {
                        echo $response;
                    }
                    /* web hook api ends */
                }
        }
        

        $message = 'success';
        $response = [
            'message' => 'success',
            'msg'     => 'Form submitted Successfully.'
        ];

        
    }else{
        $response = [
            'message' => 'error'
        ];
    }
    echo json_encode($response);
    wp_die();
}
?>