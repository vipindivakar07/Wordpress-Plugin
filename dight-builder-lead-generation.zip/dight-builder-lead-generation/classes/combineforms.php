<?php

class dight_fbuilder_combineforms{
    /**
    * combine form html
    */
    public function dight_fbuilder_combinehtml()
    {
        global $wpdb;
        $dight_fbuilder_primary_form = $wpdb->prefix.'dight_fbuilder_primary_form';
        $getprimaryforms = 'SELECT * FROM '.$dight_fbuilder_primary_form;
        $getresultprimary = $wpdb->get_results($getprimaryforms);
        $dight_fbuilder_category_form = $wpdb->prefix.'dight_fbuilder_category_form';
        $getcatforms = 'SELECT * FROM '.$dight_fbuilder_category_form;
        $getresultcat = $wpdb->get_results($getcatforms);
        if(isset($_POST['submit'])){
            $request = $_POST;
            $this->saveCombineform($request);
        }
?>
 <link rel='stylesheet' id='bootstrapcss' href='<?php echo site_url();?>/wp-content/plugins/dight-builder-lead-generation/assets/css/bootstrap.min.css' media='all' />
        <button class="toggleformfields btn btn-primary">ADD</button>
        <div class="container-fluid">
            <div id="createformfields">
                <div class="card" >
                    <div class="card-header">
                        <h4>Combined Form</h4>
                    </div>
                    <div class="requestresponse" style="display:none;"></div>
                    <div class="card-body">
                        <form action="" method="post">
                            <h5 class="card-title"> Form Name </h5>
                            <input type="text" id="cattitle" name="cattitle" style="width:100%" placeholder="Form Name" value="">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <h5 class="card-title">Select Primary Form</h5>
                                            <select id="cat_title" name="primaryform"  class="selectpicker form-control" multiple data-live-search="true" aria-label=" select option">                                          
                                                <?php
                                                if(!empty($getresultprimary)){
                                                    foreach($getresultprimary as $getresult_primary){
                                                        echo '<option value="'.$getresult_primary->id.'">'.$getresult_primary->primaryform.'</option>';
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="row">
                                            <h5 class="card-title">Select Category Form</h5>
                                            <select id="cat_title" name="catform[]"  class="selectpicker form-control" multiple data-live-search="true" aria-label=" select option">                                           
                                                <?php
                                                if(!empty($getresultcat)){
                                                    foreach($getresultcat as $getresult_category){
                                                        echo '<option value="'.$getresult_category->id.'">'.$getresult_category->categoryname.'</option>';
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </br>
                            <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="yes" name="check_splash" checked>
                            <label class="form-check-label">
                                Check for Splash Screen
                            </label>
                            </div>
                            </br>
                            <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
<?php
        echo $this->savedCombineformlist();
    }
    /**
    * combine form list
    */
    public function savedCombineformlist()
    {
        global $wpdb;
        $dight_fbuilder_combinedforms = $wpdb->prefix.'dight_fbuilder_combinedforms';  
        $dight_fbuilder_combinedforms = 'SELECT * FROM '.$dight_fbuilder_combinedforms;
        $dight_fbuilder_combinedforms = $wpdb->get_results($dight_fbuilder_combinedforms);
?>
        <div class="container-fluid mpcf">
            <div class="box">
                <h4>All Record</h4>
                <div class="requestresponse" style="display:none;"></div>
                <table id="table_id" class="table table-striped table-bordered" style="width:100%">
                    <thead>             
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Short Code</th>
                            <th>Created</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if(!empty($dight_fbuilder_combinedforms)){
                        foreach ($dight_fbuilder_combinedforms as $row) { ?>
                            <tr>
                                <td><?php echo $row->id; ?></td>
                                <td><?php echo $row->form_title; ?></td>
                                <td><?php echo $row->shortcode; ?></td>
                                <td><?php echo $row->created; ?></td>
                                <td><a class="editcombineform" rel="<?php echo $row->id; ?>" href="<?php echo admin_url('admin.php?page=edit-fbuilder-combine-form&id='.$row->id); ?>"> Edit</a> | <span class="removecombinefield" rel="<?php echo $row->id; ?>"> Delete</span> </td>
                            </tr>
                        <?php }} ?>
                    </tbody>                  
                </table> 
            </div>
        </div>
        <?php
    }
    /**
    * combine form save
    */
    public function saveCombineform($data)
    {
        global $wpdb;
        $dight_fbuilder_combinedforms = $wpdb->prefix.'dight_fbuilder_combinedforms';
        if(!empty($data)){
            $wpdb->insert( 
                $dight_fbuilder_combinedforms, 
                array(  
                    'form_title' => isset($data['cattitle']) ? $data['cattitle'] : '', 
                    'check_splash' => isset($data['check_splash']) ? $data['check_splash'] : '', 
                    'primaryform_id' => isset($data['primaryform']) ? $data['primaryform'] : '', 
                    'categoryform_id' => isset($data['catform']) ? json_encode($data['catform']) : '',
                    'created' => date('Y-m-d H:i:s')
                )
            );
            $lastid = $wpdb->insert_id;
            $wpdb->update( 
                $dight_fbuilder_combinedforms, 
                array(  
                    'shortcode' => '[fbuilder_lead_gen id="'.$lastid.'" splash="'.$data['check_splash'].'" primaryform_id="'.$data['primaryform'].'" catformsid="'.implode(',',$data['catform']).'"]'
                ),
                array( 'id' => $lastid )
              );
            $message = 'success';
        }else{
            $message = 'error';
        }
        return $message;
    }
}