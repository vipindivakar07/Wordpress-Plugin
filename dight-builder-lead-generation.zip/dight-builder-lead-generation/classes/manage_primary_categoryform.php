<?php
error_reporting(0);
class dight_fbuilder_primaryandcatform{

    public function __construct(){
    }

    /* * edit privary form  */
    public function dight_fbuilder_primaryformedit($id)
    {
        ob_start();
        global $wpdb;
        $dight_fbuilder_primary_form = $wpdb->prefix . 'dight_fbuilder_primary_form';
        $getfields = 'SELECT * FROM '.$dight_fbuilder_primary_form.' WHERE `id` = '.$id;
        $getresults = $wpdb->get_results($getfields);
        $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';
        $custom_getfields = 'SELECT * FROM '.$builder_custom_field;
        $custom_getfields = $wpdb->get_results($custom_getfields);
        $options = '';
        if(!empty($getresults)){
            $formfields = json_decode($getresults[0]->field_id);
            if(!empty($custom_getfields)){
                foreach($custom_getfields as $getresult)
                {
                    $selected = '';
                    if(in_array($getresult->id,$formfields)){
                        $selected = 'selected';
                    }
                    $options .= '<option value="'.$getresult->id.'" '.$selected.'>'.$getresult->ftitle.'</option>';
                }
            }
        }
        if ( isset( $_POST['submit'] ) ){  
            $formfields = $_POST['formfields'];
            $cattitle = $_POST['cattitle'];
            $field_value = $_POST['field_value'];
            $slidedropdown = $_POST['slidedropdown'];
            $wpdb->insert( 
                $dight_fbuilder_primary_form, 
                array(  
                    'field_id' => json_encode($formfields), 
                    'primaryform' => $cattitle, 
                    'slidedropdown' => $slidedropdown,
                    'created' => date('Y-m-d H:i:s')
                ),
                array(
                    '%s',
                    '%s',
                    '%s'
                )
            );
        }
        $html = '';
        $html .= '<div class="card" >
            <div class="card-header">
                <h4>Manage Primary form</h4>
            </div>
            <div class="requestresponse" style="display:none;"></div>
            <div class="card-body">
                <form action="" method="post">
                    <input type="text" id="cattitle" name="cattitle" style="width:100%" placeholder="Enter Title" value="'.isset($getresults[0]->primaryform)?$getresults[0]->primaryform:''.'">
                    <h5 class="card-title">Select Questions</h5>
                    <select id="cat_title" class="formfields" name="formfields[]" multiple>
                        <option value="">Please an option</option>
                        '.$options.'
                    </select>
                    <div class="dropdownoptions">
                        Would you like to display dropdown in the start of form or in the end ?
                        <input type="radio" name="slidedropdown" value="front" checked>In the start
                        <input type="radio" name="slidedropdown" value="end">In the end
                    </div>
                    </br>
                    </br>
                    <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Update</button>
                </form>
            </div>
        </div>';
        $my_var = ob_get_clean(); 
        return $html; 
    }

    /* * creating category form  */
    public function dight_fbuilder_categoryformhtml()
    {
        ob_start();
        global $wpdb;
        $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';
        $dight_fbuilder_primary_form = $wpdb->prefix . 'dight_fbuilder_category_form';
        $getfields = 'SELECT * FROM '.$builder_custom_field;
        $getresults = $wpdb->get_results($getfields);
        $options = '';
        if(!empty($getresults)){
            foreach($getresults as $getresult)
            {
                $options .= '<option value="'.$getresult->id.'">'.$getresult->ftitle.'</option>';
            }
        }
        $requestmessage = '<div class="requestresponse" style="display:none;"></div>';
        if(isset($_REQUEST['info']) && $_REQUEST['info'] == 'success'){
            $requestmessage = '<div class="requestresponse" style="color:lightgreen;">Updated successfully !</div>';
        }
        if ( isset( $_POST['submit'] ) ){  
            $formfields = $_POST['formfields'];
            $cattitle = $_POST['cattitle'];
            //$builder_custom_field = $wpdb->prefix . 'builder_custom_field';
            $wpdb->insert( 
              $dight_fbuilder_primary_form, 
              array(  
                'field_id' => json_encode($formfields), 
                'categoryname' => $cattitle, 
                'created' => date('Y-m-d H:i:s')
              ),
              array(
                '%s',
                '%s',
                '%s'
              )
            );
        }
        $queryleadgeneration = 'SELECT * FROM '.$dight_fbuilder_primary_form;
        $getleadgeneration = $wpdb->get_results($queryleadgeneration);
        $tabledata = '';
        if(!empty($getleadgeneration)){
            foreach ($getleadgeneration as $row) { 
                $tabledata .= '<tr>
                    <td>'.$row->id.'</td>
                    <td>'.$row->categoryname.'</td>
                    <td><a class="editprimaryform" rel="'.$row->id.'" href="'.admin_url('admin.php?page=edit-fbuilder-category-form&id='.$row->id).'"> Edit</a> | <span class="removecategoryform" rel="'.$row->id.'"> Delete</span></td>
                </tr>';
             }
        } 
        $html = '';
        $html .= ' <button class="toggleformfields btn btn-primary">ADD</button>
        <div id="createformfields" class="card" >
            <div class="card-header">
                <h4>Manage Categories</h4>
            </div>
            <div class="card-body">
                <form action="" method="post">
                    <input type="text" id="cattitle" name="cattitle" style="width:100%" placeholder="Enter Title">
                    <h5 class="card-title">Select Questions</h5>
                    <select id="cat_title" name="formfields[]"  class="selectpicker form-control" multiple data-live-search="true" aria-label=" select option">
                        '.$options.'
                    </select>
                    </br>
                    </br>
                    <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Save</button>
                </form>
            </div>
        </div>';
        $html .= '<div class="container-fluid mpcf">
                    <div class="box">
                    <h4>Selected Fields</h4>
                     '.$requestmessage.'
                    <table id="table_id" class="table table-striped table-bordered" style="width:100%">
                        <thead>             
                            <tr>
                                <th>ID</th>
                                <th>Category Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            '.$tabledata.'
                        </tbody>                  
                    </table>            
                </div>
        </div>';
        $my_var = ob_get_clean(); 
        return $html;   
    }

    /* * creating primary form  */
    public function dight_fbuilder_primaryformhtml()
    {
        ob_start();
        global $wpdb;
        $builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';
        $dight_fbuilder_primary_form = $wpdb->prefix . 'dight_fbuilder_primary_form';
        $getfields = 'SELECT * FROM '.$builder_custom_field;
        $getresults = $wpdb->get_results($getfields);
        $options = '';
        if(!empty($getresults)){
            foreach($getresults as $getresult)
            {
                $options .= '<option value="'.$getresult->id.'">'.$getresult->ftitle.'</option>';
            }
        }
        $requestmessage = '<div class="requestresponse" style="display:none;"></div>';
        if(isset($_REQUEST['info']) && $_REQUEST['info'] == 'success'){
            $requestmessage = '<div class="requestresponse" style="color:lightgreen;">Updated successfully !</div>';
        }
        if ( isset( $_POST['submit'] ) ){  
            $formfields = $_POST['formfields'];
            $cattitle = $_POST['cattitle'];
            $slidedropdown = $_POST['slidedropdown'];
            //$builder_custom_field = $wpdb->prefix . 'builder_custom_field';
            $wpdb->insert( 
              $dight_fbuilder_primary_form, 
              array(  
                'field_id' => json_encode($formfields), 
                'primaryform' => $cattitle, 
                'slidedropdown' => $slidedropdown,
                'created' => date('Y-m-d H:i:s')
              ),
              array(
                '%s',
                '%s',
                '%s'
              )
            );
        }
        $queryleadgeneration = 'SELECT * FROM '.$dight_fbuilder_primary_form;
        $getleadgeneration = $wpdb->get_results($queryleadgeneration);
        $tabledata = '';
        if(!empty($getleadgeneration)){
            foreach ($getleadgeneration as $row) { 
                $tabledata .= '<tr>
                    <td>'.$row->id.'</td>
                    <td>'.$row->primaryform.'</td>
                    <td><a class="editprimaryform" rel="'.$row->id.'" href="'.admin_url('admin.php?page=edit-fbuilder-primary-form&id='.$row->id).'"> Edit</a> | <span class="removeprimaryform" rel="'.$row->id.'"> Delete</span></td>
                </tr>';
             }
        } 
        $html = '';
        $html .= '<button class="toggleformfields btn btn-primary">ADD</button>
        <div id="createformfields" class="card" >
            <div class="card-header">
                <h4>Manage Primary form</h4>
            </div>
            <div class="card-body">
                <form action="" method="post">
                    <input type="text" id="cattitle" name="cattitle" style="width:100%" placeholder="Enter Title">
                    <h5 class="card-title">Select Questions</h5>
                    <select id="cat_title" name="formfields[]"  class="selectpicker form-control" multiple data-live-search="true" aria-label=" select option">
                        '.$options.'
                    </select>
                    <div class="dropdownoptions">
                        Would you like to display dropdown in the start of form or in the end ?
                        <input type="radio" name="slidedropdown" value="front" checked>In the start
                        <input type="radio" name="slidedropdown" value="end">In the end
                    </div>
                    </br>
                    </br>
                    <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Save</button>
                </form>
            </div>
        </div>';
        $html .= '<div class="container-fluid mpcf">
                  <div class="box">
                    <h4>Selected Fields</h4>
                     '.$requestmessage.'
                    <table id="table_id" class="table table-striped table-bordered" style="width:100%">
                        <thead>             
                            <tr>
                                <th>ID</th>
                                <th>Category Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            '.$tabledata.'
                        </tbody>                  
                    </table>   
                  </div>
        </div>';
        $my_var = ob_get_clean(); 
        return $html;  
    }

    /* * See all Data of Combined form  */
    public function dight_fbuilder_seealldata_formhtml()
    {
        ob_start();
        global $wpdb;
        $dight_fbuilder_seelldata_form = $wpdb->prefix . 'dight_fbuilder_combine_forms';
        $queryleadgeneration = 'SELECT * FROM '.$dight_fbuilder_seelldata_form;
        $getleadgeneration = $wpdb->get_results($queryleadgeneration);
         // echo '<pre>';
        // print_r($queryleadgeneration);
        $tabledata = '';
        if(!empty($getleadgeneration)){
            foreach ($getleadgeneration as $row) { 
                 // echo '<pre>';
                 // print_r($row);
                $alldata = $row->form_data;
                $alldataa = json_decode($alldata,true);

                $p_formid = $alldataa['primary_form_id'];
                $combined_form_id = $row->form_id;
           
                $dight_fbuilder_combined_form = $wpdb->prefix . 'dight_fbuilder_combinedforms';
                $querycombined = 'SELECT * FROM '.$dight_fbuilder_combined_form .' WHERE `id` = '.$combined_form_id;
                $getcombined = $wpdb->get_row($querycombined);
                
                $dight_fbuilder_primary_form = $wpdb->prefix . 'dight_fbuilder_primary_form';
                $query = 'SELECT * FROM '.$dight_fbuilder_primary_form .' WHERE `id` = '.$p_formid;
                $getres = $wpdb->get_row($query);
        //'.$alldataa["ff_33"].','.$alldataa["ff_34"].','.$alldataa["ff_50"].','.$alldataa["ff_35"].','.$alldataa["ff_38"].','.$alldataa["ff_45"].',
                $tabledata .= '<tr>
                    <td>'.$row->id.'</td>
                    <td>'.$getcombined->form_title.'</td>
                    <td>'.$getres->primaryform.'</td>
                    <td>'.$row->nonce.'</td>
                    <td>'.$alldataa["ff_22"].' '.$alldataa["ff_23"].'</td>
                    <td>'.$alldataa["ff_24"].'</td>
                    <td>'.$alldataa["ff_25"].'</td>
                    <td>'.$alldataa["ff_26"].','.$alldataa["ff_27"].','.$alldataa["ff_28"].','.$alldataa["ff_29"].'</td>
                     <td>'.$alldataa["ff_30"].','.$alldataa["ff_37"].','.$alldataa["ff_36"].'</td>
                     <?
                    </tr>';
            }
        } 
        $html = '';
        $html .= '<div class="wrap"><h2>See All Data here</h2></div><div class="container-fluid mpcf">
                  <div class="box">
                    <h4>All Combined Forms Record</h4>
                     '.$requestmessage.'
                    <table id="table_id" class="table table-striped table-bordered" style="width:100%">
                        <thead>             
                            <tr>
                                <th>ID</th>
                                <th>Combined Form</th>
                                <th>Primary Form</th>
                                <th>Nonce</th>
                                <th>Full Name</th>
                                <th>Phone Number</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Question</th>
                            </tr>
                        </thead>
                        <tbody>
                            '.$tabledata.'
                        </tbody>                  
                    </table>   
                  </div>
                </div>';
        $my_var = ob_get_clean(); 
        return $html;  
    }

    /* * creating splash form  */
    public function dight_fbuilder_buildersplash_screen_form()
    {
        $requestmessage = '<div class="requestresponse" style="display:none;"></div>';
        if(isset($_REQUEST['info']) && $_REQUEST['info'] == 'success'){
            $requestmessage = '<div class="requestresponse" style="color:lightgreen;">Created successfully !</div>';
        }
        ob_start();
        global $wpdb; 
        $dight_fbuilder_splash_forms = $wpdb->prefix . 'dight_fbuilder_splash_forms';
        $splash_screen_get = 'SELECT * FROM '.$dight_fbuilder_splash_forms;
        $row = $wpdb->get_results($splash_screen_get);
        $upload_dir = wp_upload_dir();
        $path = $upload_dir['baseurl'].'/splash/';
        $id = $row[0]->id;

        if ( isset( $_POST['submit'] ) ){  
           //start image upload
            $file_path = $_FILES['file']['name'];
            $tmp_file_name = $_FILES['file']['tmp_name'];
            $upload_dir = wp_upload_dir();
            $path = $upload_dir['basedir'].'/splash/';
            if ( !is_dir( $path  ) ) {
                mkdir( $path  );
            }
            if($file_path){
                move_uploaded_file($tmp_file_name,$path.$file_path);
            }
            //end image upload
            $title = $_POST['title'];
            $description = $_POST['description'];
            if(count($row) == 0)
            {
                $wpdb->insert( 
                    $dight_fbuilder_splash_forms, 
                    array(  
                        'file' => $file_path,
                        'title' => $title, 
                        'description' => $description, 
                        'created' => date('Y-m-d H:i:s')
                    ),
                    array(
                        '%s',
                        '%s',
                        '%s'
                    )
                );
            }
            else
            {
                if($file_path){
                    $wpdb->update( 
                        $dight_fbuilder_splash_forms, 
                        array(  
                            'file' => $file_path,
                            'title' => $title, 
                            'description' => $description, 
                            'modified' => date('Y-m-d H:i:s')
                        ),
                        array( 'id' => $id )
                    );
                }else{
                    $wpdb->update( 
                        $dight_fbuilder_splash_forms, 
                        array(  
                            'title' => $title, 
                            'description' => $description, 
                            'modified' => date('Y-m-d H:i:s')
                        ),
                        array( 'id' => $id )
                    );
                }
                wp_redirect(
                    esc_url_raw(
                        add_query_arg(
                            array(
                                'info'     => 'success',
                                'response' => 'success',
                            ),
                            'admin.php?page=Splash-Screen'  
                        )
                    )
                );
            }
        }
        ?>
        <style>
        article, aside, figure, footer, header, hgroup, menu, nav, section 
        { 
            display: block;
        }
        </style>
        <div class="card" >
            <div class="card-header">
                <h4>Splash Screen</h4>
            </div>
            <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data">
                    <h5 class="card-title">Image</h5>
                    <input type="file" id="file" name="file" style="width:100%" onchange="readURL(this);" >
                    <img style="height:200px; width:150px;" id="blah" src="<?php echo $path.''.$row[0]->file ?>"></img>
                    <h5 class="card-title">Title</h5>
                    <input type="text" id="title" name="title" style="width:100%" placeholder="Enter Title" value="<?php echo $row[0]->title; ?>" required>
                    <h5 class="card-title">Description</h5>
                    <textarea id="editor1" name="description" rows="4" cols="90" required><?php echo $row[0]->description; ?></textarea>
                    </br>
                    </br>
                    <button type="submit" value="Submit"  class="btn btn-primary " name="submit">Save</button>
                </form>
            </div>
        </div>
        <script src="https://cdn.ckeditor.com/4.20.2/standard-all/ckeditor.js"></script>
        <link class="jsbin" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/base/jquery-ui.css" />
        <script class="jsbin" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.0/jquery-ui.min.js"></script>
        <script>
            CKEDITOR.replace('editor1', {
                fullPage: false,
                extraPlugins: 'docprops',
                // Disable content filtering because if you use full page mode, you probably
                // want to  freely enter any HTML content in source mode without any limitations.
                allowedContent: false,
                height: 320,
                removeButtons: 'PasteFromWord'
            });
            //Function for preview Image
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#blah')
                            .attr('src', e.target.result)
                            .width(150)
                            .height(200);
                    };
                    reader.readAsDataURL(input.files[0]);
                }
            }
        </script>
<?php
    }
    public function dight_fbuilder_setting_form()
    {
        $requestmessage = '<div class="requestresponse" style="display:none;"></div>';
        if(isset($_REQUEST['info']) && $_REQUEST['info'] == 'success'){
            $requestmessage = '<div class="requestresponse" style="color:lightgreen;">Created successfully !</div>';
        }
        global $wpdb;
        $dight_fbuilder_setting_forms = $wpdb->prefix . 'dight_fbuilder_setting_forms';
        $querysettingform = 'SELECT * FROM '.$dight_fbuilder_setting_forms;
        $getresult = $wpdb->get_results($querysettingform);
        $id = $getresult[0]->id;
        $termp = $getresult[0]->term_policy;
        $legal_disclamer = $getresult[0]->legal_disclamer;
        $enabledp = $getresult[0]->enabledpolicy;
        if ( isset( $_POST['submit'] ) ){    
            $term_policy = $_POST['term_policy'];
            $legal_disclamer = $_POST['legal_disclamer'];
            $checked = 'no';
            if(isset($_POST['enabledpolicy']) && $_POST['enabledpolicy'] != ''){
                $checked = $_POST['enabledpolicy'];
            }      
            if(count($getresult) == 0)
            {
                $wpdb->insert( 
                    $dight_fbuilder_setting_forms, 
                    array(  
                        'term_policy' => $term_policy, 
                        'legal_disclamer' => $legal_disclamer,
                        'enabledpolicy' => $checked,
                        'created' => date('Y-m-d H:i:s')
                    ),
                    array(
                        '%s',
                        '%s',
                        '%s'
                    )
                );
            }
            else
            {
            $wpdb->update( 
                $dight_fbuilder_setting_forms, 
                array(  
                    'term_policy' => $term_policy, 
                    'legal_disclamer' => $legal_disclamer,
                    'enabledpolicy' => $checked,
                    'modified' => date('Y-m-d H:i:s')
                ),
                array( 'id' => $id )
            );
            wp_redirect(
                esc_url_raw(
                    add_query_arg(
                        array(
                            'info'     => 'success',
                            'response' => 'success',
                        ),
                        'admin.php?page=setting'  
                    )
                )
            );
            }
        }
        ?>
        <div class="container-fluid">
            <div>
                <h3>Menu</h3>
                <a href="#"><h4>Terms & policy</h4></a>
            </div>
            <div  class="card" >
                <div class="card-header">
                    <h4>Policy Setting</h4>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <h5 class="card-title">Terms & Policy</h5>
                        <input type="text" id="term_policy" name="term_policy" value="<?php echo $termp; ?>" style="width:100%" placeholder="Enter Title">
                        <h5 class="card-title">Legal Disclamer</h5>
                        <input type="text" id="legal_disclamer" name="legal_disclamer" value="<?php echo $legal_disclamer; ?>" style="width:100%" placeholder="Enter Legal Disclamer">
                        <input type="checkbox" class="form-check-input" id="enabledpolicy" <?php echo ($enabledp == 'yes' ? 'checked' : ''); ?> value="yes" name="enabledpolicy">
                        <label class="form-check-label" for="exampleCheck1">Enable/Disable</label>
                        </br> </br>
                        <button type="submit" value="Submit"  class="btn btn-primary" name="submit">Save</button>
                    </form>
                </div>
            </div>
        </div>
<?php
    }
}
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">