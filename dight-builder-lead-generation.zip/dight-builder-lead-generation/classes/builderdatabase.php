<?php
class dight_fbuilder_form_field{

  public function __construct(){
    //add_action('admin_menu',array($this,'pluginAdminMenu'));
    //register_activation_hook( __FILE__, arrray($this,'builder_custom_fields' ));
    add_action('admin_init',array($this,'dight_fbuilder_custom_fields'));
  }

  public function dight_fbuilder_custom_fields()
  {      
    global $wpdb; 
    $wp_builder_custom_field = $wpdb->prefix . 'dight_fbuilder_custom_field';  // table name
    $charset_collate = $wpdb->get_charset_collate();

    //Check to see if the table exists already, if not, then create it

    if($wpdb->get_var( "show tables like '$wp_builder_custom_field'" ) != $wp_builder_custom_field ) 
    {  
      $sql = "CREATE TABLE $wp_builder_custom_field (
                  `id` int(11) NOT NULL auto_increment,
                  `ftitle` varchar(250) NOT NULL,
                  `field_type` varchar(60) NOT NULL,
                  `field_value` varchar(250) NOT NULL,
                  `required_field` varchar(250) NOT NULL,
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
      //add_option( 'db_version', '1.0' );
    }
    $builder_primary_form = $wpdb->prefix . 'dight_fbuilder_primary_form';  // table name

    //Check to see if the table exists already, if not, then create it
    if($wpdb->get_var( "show tables like '$builder_primary_form'" ) != $builder_primary_form ) 
    {  
      $sql = "CREATE TABLE $builder_primary_form (
                  `id` int(11) NOT NULL auto_increment,
                  `field_id` LONGTEXT NOT NULL,
                  `primaryform` varchar(255) NOT NULL,
                  `slidedropdown` varchar(255) NOT NULL,
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  `modified` datetime DEFAULT CURRENT_TIMESTAMP, 
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
      //add_option( 'db_version', '1.0' );
    }

    $dight_fbuilder_category_form = $wpdb->prefix . 'dight_fbuilder_category_form';  
    if($wpdb->get_var( "show tables like '$dight_fbuilder_category_form'" ) != $dight_fbuilder_category_form ) 
    {  
      $sql = "CREATE TABLE $dight_fbuilder_category_form (
                  `id` int(11) NOT NULL auto_increment,
                  `field_id` LONGTEXT NOT NULL,
                  `categoryname` varchar(255) NOT NULL,
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  `modified` datetime DEFAULT CURRENT_TIMESTAMP, 
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
      //add_option( 'db_version', '1.0' );
    }

    $dight_fbuilder_combinedforms = $wpdb->prefix . 'dight_fbuilder_combinedforms';  
    if($wpdb->get_var( "show tables like '$dight_fbuilder_combinedforms'" ) != $dight_fbuilder_combinedforms ) 
    {  
      $sql = "CREATE TABLE $dight_fbuilder_combinedforms (
                  `id` int(11) NOT NULL auto_increment,
                  `form_title` varchar(255) NOT NULL,
                  `check_splash` varchar(255) NOT NULL,
                  `primaryform_id` int(11) NOT NULL,
                  `categoryform_id` LONGTEXT NOT NULL,
                  `shortcode` LONGTEXT NOT NULL,
                  `map_fields` LONGTEXT NOT NULL,
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  `modified` datetime DEFAULT CURRENT_TIMESTAMP, 
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
      //add_option( 'db_version', '1.0' );
    }

    $dight_fbuilder_combine_forms = $wpdb->prefix . 'dight_fbuilder_combine_forms';  
    if($wpdb->get_var( "show tables like '$dight_fbuilder_combine_forms'" ) != $dight_fbuilder_combine_forms ) 
    {  
      $sql = "CREATE TABLE $dight_fbuilder_combine_forms (
                  `id` int(11) NOT NULL auto_increment,
                  `form_id` int(11) NOT NULL,
                  `form_data` LONGTEXT NOT NULL,
                  `nonce` varchar(255) NOT NULL, 
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  `modified` datetime DEFAULT CURRENT_TIMESTAMP, 
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
    }

    $dight_fbuilder_setting_forms = $wpdb->prefix . 'dight_fbuilder_setting_forms';  
    if($wpdb->get_var( "show tables like '$dight_fbuilder_setting_forms'" ) != $dight_fbuilder_setting_forms ) 
    {  
      $sql = "CREATE TABLE $dight_fbuilder_setting_forms (
                  `id` int(11) NOT NULL auto_increment,
                  `term_policy` LONGTEXT NOT NULL,
                  `legal_disclamer` LONGTEXT NOT NULL,
                  `enabledpolicy` LONGTEXT NOT NULL,
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  `modified` datetime DEFAULT CURRENT_TIMESTAMP, 
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
    }

    $dight_fbuilder_splash_screen_forms = $wpdb->prefix . 'dight_fbuilder_splash_forms';  
    if($wpdb->get_var( "show tables like '$dight_fbuilder_splash_screen_forms'" ) != $dight_fbuilder_splash_screen_forms ) 
    {  
      $sql = "CREATE TABLE $dight_fbuilder_splash_screen_forms (
                  `id` int(11) NOT NULL auto_increment,
                  `file` LONGTEXT NOT NULL,
                  `title` LONGTEXT NOT NULL,
                  `description` LONGTEXT NOT NULL,
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  `modified` datetime DEFAULT CURRENT_TIMESTAMP, 
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
    }
  } 
}

?>