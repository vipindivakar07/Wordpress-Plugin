jQuery(document).ready(function(){
    jQuery('.removeprimaryform').click(function(){
        var ajax_url = plugin_ajax_object.ajax_url;
        var formid = jQuery(this).attr('rel');
        var data = {
            'action': 'dight_fbuilder_deleteprimaryform',
            'formid':formid,
        };
        $.ajax({
            url: ajax_url,
            type: 'post',
            data: data,
            dataType: 'json',
            success: function(response){
                if(response == 'success'){
                    jQuery('.requestresponse').css('color','lightgreen');
                    jQuery('.requestresponse').show();
                    jQuery('.requestresponse').text('Removed Successfully');
                    setTimeout(function(){
                        location.reload();
                    }, 1500);
                }else{
                    jQuery('.requestresponse').css('color','red');
                    jQuery('.requestresponse').show();
                    jQuery('.requestresponse').text('Went something wrong!'); 
                }
            }
        });
    });
    jQuery('.removeformfield').click(function(){
        var ajax_url = plugin_ajax_object.ajax_url;
        var formid = jQuery(this).attr('rel');
        var data = {
            'action': 'dight_fbuilder_deleteformfield',
            'formid':formid,
        };
        $.ajax({
            url: ajax_url,
            type: 'post',
            data: data,
            dataType: 'json',
            success: function(response){
                if(response == 'success'){
                    jQuery('.requestresponse').css('color','lightgreen');
                    jQuery('.requestresponse').show();
                    jQuery('.requestresponse').text('Removed Successfully');
                    setTimeout(function(){
                        location.reload();
                    }, 1500);
                }else{
                    jQuery('.requestresponse').css('color','red');
                    jQuery('.requestresponse').show();
                    jQuery('.requestresponse').text('Went something wrong!'); 
                }
            }
        });
    });
    jQuery('.removecategoryform').click(function(){
        var ajax_url = plugin_ajax_object.ajax_url;
        var formid = jQuery(this).attr('rel');
        var data = {
            'action': 'dight_fbuilder_deletecategoryform',
            'formid':formid,
        };
        $.ajax({
            url: ajax_url,
            type: 'post',
            data: data,
            dataType: 'json',
            success: function(response){
                if(response == 'success'){
                    jQuery('.requestresponse').css('color','lightgreen');
                    jQuery('.requestresponse').show();
                    jQuery('.requestresponse').text('Removed Successfully');
                    setTimeout(function(){
                        location.reload();
                    }, 1500);
                }else{
                    jQuery('.requestresponse').css('color','red');
                    jQuery('.requestresponse').show();
                    jQuery('.requestresponse').text('Went something wrong!'); 
                }
            }
        });
    });
    jQuery('.removecombinefield').click(function(){
        var ajax_url = plugin_ajax_object.ajax_url;
        var formid = jQuery(this).attr('rel');
        var data = {
            'action': 'dight_fbuilder_deletecombineform',
            'formid':formid,
        };
        $.ajax({
            url: ajax_url,
            type: 'post',
            data: data,
            dataType: 'json',
            success: function(response){
                if(response == 'success'){
                    jQuery('.requestresponse').css('color','lightgreen');
                    jQuery('.requestresponse').show();
                    jQuery('.requestresponse').text('Removed Successfully');
                    setTimeout(function(){
                        location.reload();
                    }, 1500);
                }else{
                    jQuery('.requestresponse').css('color','red');
                    jQuery('.requestresponse').show();
                    jQuery('.requestresponse').text('Went something wrong!'); 
                }
            }
        });
    });
    
    setTimeout(function(){
        jQuery('.requestresponse').hide();
    },1500)



   
    
});
