<?php

class dight_fbuilder_formCommon {

  public function __construct()
  {
    add_action('admin_init', array($this,'dight_fbuilder_menus'));
  }

  public function dight_fbuilder_menus()
  {
    wp_register_style( 'builderformcss', plugins_url('../assets/css/builderForm.css',__FILE__) );
    wp_enqueue_style( 'builderformcss' );
    //wp_register_style( 'bootstrapcss', plugins_url('../assets/css/bootstrap.min.css',__FILE__) );
    //wp_enqueue_style( 'bootstrapcss' );
    wp_register_style( 'dataTablescss', plugins_url('../assets/css/dataTables.min.css',__FILE__) );
    wp_enqueue_style( 'dataTablescss' );

    wp_register_style( 'bootstrapselectcss', plugins_url('../assets/css/bootstrap-select.css',__FILE__) );
    wp_enqueue_style( 'bootstrapselectcss' );
    
    wp_register_script( 'jqueryminjs', plugins_url('../assets/js/jquery.min.js',__FILE__),array( 'jquery' )  );
    wp_enqueue_script( 'jqueryminjs');    

    wp_register_script( 'jquerydataables', plugins_url('../assets/js/jquery.dataTables.min.js',__FILE__),array( 'jquery' )  );
    wp_enqueue_script( 'jquerydataables');

    wp_register_script( 'builderforjs', plugins_url('../assets/js/builderForm.js',__FILE__),array( 'jquery' )  );
    wp_enqueue_script( 'builderforjs');

    wp_register_script( 'bootstrapminjs', plugins_url('../assets/js/bootstrap.min.js',__FILE__),array( 'jquery' )  );
    wp_enqueue_script( 'bootstrapminjs');

    wp_register_script( 'bootstrapselectjs', plugins_url('../assets/js/bootstrap-select.js',__FILE__),array( 'jquery' )  );
    wp_enqueue_script( 'bootstrapselectjs');

    wp_enqueue_script( 'fbuiderajax', plugins_url( '../assets/js/fbuilderajax.js',__FILE__ ),array('jquery'));
    wp_localize_script( 'fbuiderajax', 'plugin_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
  }  
}

?>