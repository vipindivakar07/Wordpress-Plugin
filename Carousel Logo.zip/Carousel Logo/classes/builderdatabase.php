<?php

class dight_fbuilder_form_field{

  public function __construct(){
    //add_action('admin_menu',array($this,'pluginAdminMenu'));
    //register_activation_hook( __FILE__, arrray($this,'builder_custom_fields' ));
    add_action('admin_init',array($this,'dight_fbuilder_custom_fields'));
  }

  public function dight_fbuilder_custom_fields()
  {      
    global $wpdb; 
    $charset_collate = $wpdb->get_charset_collate();

    //Check to see if the table exists already, if not, then create it

  
    $dight_fbuilder_setting_forms = $wpdb->prefix . 'dight_fbuilder_setting_forms';  
    if($wpdb->get_var( "show tables like '$dight_fbuilder_setting_forms'" ) != $dight_fbuilder_setting_forms ) 
    {  
      $sql = "CREATE TABLE $dight_fbuilder_setting_forms (
                  `id` int(11) NOT NULL auto_increment,
                  `images` LONGTEXT NOT NULL,
                  `duration` LONGTEXT NOT NULL,
                  `showimg` LONGTEXT NOT NULL,
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  `modified` datetime DEFAULT CURRENT_TIMESTAMP, 
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
    }

    $dight_fbuilder_splash_screen_forms = $wpdb->prefix . 'dight_fbuilder_splash_forms';  
    if($wpdb->get_var( "show tables like '$dight_fbuilder_splash_screen_forms'" ) != $dight_fbuilder_splash_screen_forms ) 
    {  
      $sql = "CREATE TABLE $dight_fbuilder_splash_screen_forms (
                  `id` int(11) NOT NULL auto_increment,
                  `file` LONGTEXT NOT NULL,
                  `created` datetime DEFAULT CURRENT_TIMESTAMP,
                  `modified` datetime DEFAULT CURRENT_TIMESTAMP, 
                  UNIQUE KEY id (id)
      ) $charset_collate;";
      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
    }
  } 
}

?>