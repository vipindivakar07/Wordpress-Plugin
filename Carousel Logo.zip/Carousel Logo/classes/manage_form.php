<?php
//error_reporting(0);

require_once( ABSPATH . 'wp-admin/includes/file.php' );
class dight_fbuilder_primaryandcatform{

    public function __construct(){
    }

    /* * creating  form  */
public function dight_fbuilder_buildersplash_screen_form() {
    $requestmessage = '<div class="requestresponse" style="display:none;"></div>';
    if (isset($_REQUEST['info']) && $_REQUEST['info'] == 'success') {
        $requestmessage = '<div class="requestresponse" style="color:lightgreen;">Created successfully !</div>';
    }
    ob_start();
    global $wpdb;
    $dight_fbuilder_splash_forms = $wpdb->prefix . 'dight_fbuilder_splash_forms';

    if (isset($_POST['submit'])) {
        // Check if a file was uploaded
        if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
            // Define the upload directory using WordPress function
            $upload_dir = wp_upload_dir();
            $path = $upload_dir['path'] . '/'; // Use 'path' instead of 'basedir'

            // Generate a unique file name
            $unique_file_name = wp_unique_filename($path, $_FILES['file']['name']);

            // Move the uploaded file to the destination directory with the unique name
            $move_result = move_uploaded_file($_FILES['file']['tmp_name'], $path . $unique_file_name);

            if ($move_result) {
                // Insert file information into the database
                global $wpdb;
                $dight_fbuilder_splash_forms = $wpdb->prefix . 'dight_fbuilder_splash_forms';

                $wpdb->insert(
                    $dight_fbuilder_splash_forms,
                    array(
                        'file' => $unique_file_name, // Store the unique file name, not the file array
                        'created' => date('Y-m-d H:i:s')
                    ),
                    array(
                        '%s', // 'file' is a string
                        '%s'  // 'created' is a string
                    )
                );

                echo 'File uploaded successfully.';
            } else {
                // Handle file move error
                echo 'File move error.';
            }
        } else {
            // Handle file upload error
            echo 'File upload error: ' . $_FILES['file']['error'];
        }
    }

  ?>

    <div class="card">
        <div class="card-header">
            <h4>Upload Image</h4>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <h5 class="card-title">Image</h5>
                <input type="file" id="file" name="file" style="width:100%" >
                <br>
                <button type="submit" value="Submit" class="btn btn-primary" name="submit">Save</button>
            </form>
        </div>
    </div>

    <?php
}

    
    public function dight_fbuilder_setting_form()
    {
        $requestmessage = '<div class="requestresponse" style="display:none;"></div>';
        if(isset($_REQUEST['info']) && $_REQUEST['info'] == 'success'){
            $requestmessage = '<div class="requestresponse" style="color:lightgreen;">Created successfully !</div>';
        }
        global $wpdb;
        $dight_fbuilder_setting_forms = $wpdb->prefix . 'dight_fbuilder_setting_forms';
        $querysettingform = 'SELECT * FROM '.$dight_fbuilder_setting_forms;
        $getresult = $wpdb->get_results($querysettingform);
        if(count($getresult) !== 0){
        $id = $getresult[0]->id;
        $termp = $getresult[0]->images;
        $duration = $getresult[0]->duration;
        $enabledp = $getresult[0]->showimg;
        }
        if ( isset( $_POST['submit'] ) ){    
            $images = $_POST['images'];
            $duration = $_POST['duration'];
            if(isset($_POST['showimg']) && $_POST['showimg'] != ''){
                $checked = $_POST['showimg'];
            }      
            if(count($getresult) == 0)
            {
                $wpdb->insert( 
                    $dight_fbuilder_setting_forms, 
                    array(  
                        'images' => $images, 
                        'duration' => $duration,
                        'showimg' => $checked,
                        'created' => date('Y-m-d H:i:s')
                    ),
                    array(
                        '%s',
                        '%s',
                        '%s'
                    )
                );
            }
            else
            {
            $wpdb->update( 
                $dight_fbuilder_setting_forms, 
                array(  
                    'images' => $images, 
                    'duration' => $duration,
                    'showimg' => $checked,
                    'modified' => date('Y-m-d H:i:s')
                ),
                array( 'id' => $id )
            );
            wp_redirect(
                esc_url_raw(
                    add_query_arg(
                        array(
                            'info'     => 'success',
                            'response' => 'success',
                        ),
                        'admin.php?page=setting'  
                    )
                )
            );
            }
        }
        ?>
        <div class="container-fluid">
            <div>
                <h3>Setting</h3>
            </div>
            <div  class="card" >
                <div class="card-header">
                    <h4> Setting</h4>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <h5 class="card-title">How many images slide at a time.</h5>
                        <input type="number" id="images" name="images" value="<?php echo $termp; ?>" style="width:100%" >
                        <h5 class="card-title">Slide delay duration(in Sec).</h5>
                        <input type="number" id="duration" name="duration" value="<?php echo $duration; ?>" style="width:100%" placeholder="Enter duration">
                        
                        <h5 class="card-title">How many images will show in the slider.</h5>
                        <input type="number" class="form-check-input" id="showimg"  value="<?php echo $enabledp; ?>" name="showimg">
                        
                        </br> </br>
                        <button type="submit" value="Submit"  class="btn btn-primary" name="submit">Save</button>
                    </form>
                </div>
            </div>
        </div>
<?php
    }
}
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">