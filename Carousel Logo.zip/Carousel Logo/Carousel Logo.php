<?php
/** 
 * Plugin Name: Carousel Logo
 * Description: just an example for the Carousel Logo
 * Plugin URI: https://www.vipindivakar.com/
* Version: 1.1
* Author: Vipin Divakar
* Author URI: https://www.vipindivakar.com/
*/

global $dight_fbuilder_lead_generation_version,$dight_fbuilder_lead_generation_db_version;
$dight_fbuilder_lead_generation_version = '1.0';
$dight_fbuilder_lead_generation_db_version = '1.0';
define( 'dight_fbuilder_lead_generation_plugin_path', plugins_url(__FILE__ ) ); 
define( 'dight_fbuilder_lead_generation_plugin_dir_path', plugin_dir_path(__FILE__ ) ); 
require_once('classes/builderdatabase.php' );
require_once('classes/function.php' );

function admin_menu(){
    add_menu_page('Forms','Plugin','manage_options','dight-fbuilder-create-form','dight_fbuilder_lead_admin_menu','dashicons-cart',4);
    add_submenu_page('dight-fbuilder-create-form','Setting','Setting','manage_options','setting','dight_fbuilder_setting');
    add_submenu_page('dight-fbuilder-create-form','Upload Image','Upload Image','manage_options','upload-image','upload_image');
       new dight_fbuilder_formCommon();
    new dight_fbuilder_form_field();
}
add_action('admin_menu','admin_menu');

function dight_fbuilder_lead_admin_menu(){
    echo "hello";
}

function upload_image(){
    require_once('classes/manage_form.php' );
    $buildersplash_screenform = new dight_fbuilder_primaryandcatform();
    echo $buildersplash_screenform->dight_fbuilder_buildersplash_screen_form();
}

function dight_fbuilder_setting(){
    require_once('classes/manage_form.php' );
    $builder_setting_form = new dight_fbuilder_primaryandcatform();
    echo $builder_setting_form->dight_fbuilder_setting_form();
}



// Create a function to retrieve image file paths and settings from the custom table
function get_splash_screen_data() {
    global $wpdb;
    $dight_fbuilder_splash_forms = $wpdb->prefix . 'dight_fbuilder_splash_forms';
    $dight_fbuilder_setting_forms = $wpdb->prefix . 'dight_fbuilder_setting_forms';

    // Define your custom SQL queries to select file paths and settings
    $image_query = "SELECT file FROM $dight_fbuilder_splash_forms";
    $settings_query = "SELECT images, duration, showimg FROM $dight_fbuilder_setting_forms";

    // Execute the queries
    $image_results = $wpdb->get_results($image_query);
    
    $settings_results = $wpdb->get_results($settings_query);
   //print_r($settings_results);
    // Create an array to store image file paths and settings
    $speed ="";
    $showing ="";
    $images ="";
    foreach ($settings_results as $item2) {
         $speed = $item2->duration;
         $showing = $item2->showimg;
         $images = $item2->images;
    }
 
     
   //}
?>
<style>
body{
  background-color: #F5F5FF;
}
.wrapper{
  padding: 70px 0;
}
/* Default slide */ 
.my-slider .slick-slide{
  background-color: #787878;
  color: #FFF;
  height: 200px;
  margin: 0 15px 0 0;
  display: flex;
  align-items: center;
  justify-content: center;
  transform: scale(0.8);
  transition: all 0.4s ease-in-out;
}

.slick-next, .slick-prev{
  z-index: 5;
}
.slick-next{
  right: 15px;
}
.slick-prev{
  left: 15px;
}
.slick-next:before, .slick-prev:before{
  color: #000;
  font-size: 26px;
}
  </style>  
 
    <link href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
	
<div class="wrapper">

  <div class="my-slider">
  <?php
    $allimg =[];
    $upload_dir = wp_upload_dir();
    $uploads_url = $upload_dir['baseurl'] . '/';
    
    for ($i = 0; $i < $showing; $i++) {
        $item = $image_results[$i];
        $allimg = $uploads_url . $item->file;
        ?>
        <div class="my-slide" ><img src="<?php echo $allimg; ?>"/></div> <?php
    }
    ?>
    </div>
   
</div>

<script>
$(document).ready(function(){  
    let speees = <?php echo json_encode($speed);  ?>;
    let images = <?php echo json_encode($images);  ?>;
   
  // get the number of slides
  var total = $('.my-slider .my-slide').length,      
    rand = Math.floor( Math.random() * total ); // random number
  
      $('.my-slider').slick({
        slidesToShow: images,
        slidesToScroll: 1,
        arrows: false,
        dots: true,
        speed: speees,
        infinite: true,
        autoplaySpeed: 100,
        slide: ".my-slide",
        autoplay: true
      });
  $('.my-slider').slick('slickGoTo', rand);
  //this is also works $('.my-slider')[0].slick.slickGoTo(rand);
 
});
    </script>
   <?php
   
}
add_shortcode('splash_screen_carousel', 'get_splash_screen_data');

?>